package com.rackspace.sl.constants;

/**
 * The Class SLConstants.
 */
public class SLConstants {

	/** The Constant POST. */
	public static final String POST = "POST";

	/** The Constant GET. */
	public static final String GET = "GET";

	/** The Constant ACCEPT_APPLICATION_JSON. */
	public static final String ACCEPT_APPLICATION_JSON = "application/json";

	/** The Constant CONTENT_TYPE_APPLICATION_JSON. */
	public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";

	/** The Constant ACCEPT_APPLICATION_XML. */
	public static final String ACCEPT_APPLICATION_XML = "application/xml";

	/** The Constant CONTENT_TYPE_APPLICATION_XML. */
	public static final String CONTENT_TYPE_APPLICATION_XML = "application/xml";

	/** The Constant ENVIORNMENT. */
	public static final String ENVIORNMENT = "enviornment";

	/** The Constant NOTIFICATION_QUERY. */
	public static final String NOTIFICATION_QUERY = "notificationQuery";

	/** The Constant NOTIFICATION_QUERY_NOTIFY. */
	public static final String NOTIFICATION_QUERY_NOTIFY = "notificationQueryNotify";

	/** The Constant NOTIFICATION_QUERY_BSL. */
	public static final String NOTIFICATION_QUERY_BSL = "notificationQueryBSL";

	/** The Constant PCM_OP_PUBLISH_GEN_PAYLOAD_FILE_PATH. */
	public static final String PCM_OP_PUBLISH_GEN_PAYLOAD_FILE_PATH = "src/com/rackspace/brm/account/templates/PCM_OP_PUBLISH_GEN_PAYLOAD.nap";

	/** The Constant BILLING_PROBLEM_CHARGE_CC_FILE_PATH. */
	public static final String BILLING_PROBLEM_CHARGE_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PROBLEM_CHARGE_CC.nap";

	/** The Constant BILLING_PROBLEM_CHARGE_ACH_FILE_PATH. */
	public static final String BILLING_PROBLEM_CHARGE_ACH_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PROBLEM_CHARGE_ACH.nap";

	/** The Constant SPEND_THRESHOLD_LIMIT_FILE_PATH. */
	public static final String SPEND_THRESHOLD_LIMIT_FILE_PATH = "src/com/rackspace/brm/account/templates/SPEND_THRESHOLD_LIMIT.nap";

	/** The Constant BILLING_PREDRAFT_NOTIFICATION_FILE_PATH. */
	public static final String BILLING_PREDRAFT_NOTIFICATION_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PREDRAFT_NOTIFICATION.nap";

	/** The Constant BILLING_EXPIRY_CC_FILE_PATH. */
	public static final String BILLING_EXPIRY_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_EXPIRY_CC.nap";

	/** The Constant EMAIL_INVOICE_PDF_FILE_PATH. */
	public static final String EMAIL_INVOICE_PDF_FILE_PATH = "src/com/rackspace/brm/account/templates/EMAIL_INVOICE_PDF.nap";

	/** The Constant BILLING_PAYMENT_SUCCESS_CC_FILE_PATH. */
	public static final String BILLING_PAYMENT_SUCCESS_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PAYMENT_SUCCESS_CC.nap";

	/** The Constant EXPIRY_CC_NOTIFICATION_FILE_PATH. */
	public static final String EXPIRY_CC_NOTIFICATION_FILE_PATH = "src/com/rackspace/brm/account/templates/EXPIRY_CC_NOTIFICATION.nap";

	/** The Constant UKDD_PAYMENT_INITIATED_FILE_PATH. */
	public static final String UKDD_PAYMENT_INITIATED_FILE_PATH = "src/com/rackspace/brm/account/templates/UKDD_PAYMENT_INITIATED.nap";

	/** The Constant UKDD_PAYMENT_FAILED_FILE_PATH. */
	public static final String UKDD_PAYMENT_FAILED_FILE_PATH = "src/com/rackspace/brm/account/templates/UKDD_PAYMENT_FAILED.nap";

	/** The Constant ACCOUNTCREATION_ACH_FILE_PATH. */
	public static final String ACCOUNTCREATION_ACH_FILE_PATH = "src/com/rackspace/brm/account/templates/CreateAchUSAccount.json";

	/** The Constant DEDICATED_ACCT_CREATE_JSON_FILE_PATH. */
	public static final String DEDICATED_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/CreateDedicatedUSAccount.json";

	/** The Constant SET_DEFAULT_CC_FILE_PATH. */
	public static final String SET_DEFAULT_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/setDefaultMethodCC.json";

	/** The Constant CREATE_CC_METHOD_FILE_PATH1. */
	public static final String CREATE_CC_METHOD_FILE_PATH1 = "src/com/rackspace/brm/account/templates/createCCMethod.json";

	/** The Constant CREATEMETHODVALIDATION_CC_FILE_PATH. */
	public static final String CREATEMETHODVALIDATION_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/createCCMethodValidation.json";

	/** The Constant FINALIZED_METHOD_CREATION_CC_FILE_PATH. */
	public static final String FINALIZED_METHOD_CREATION_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/FinalizedMethodCreation.json";
	/** The Constant CREATE_DEDICATED_SL_ACCOUNT_URI. */
	public static final String CREATE_DEDICATED_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";

	/** The Constant CREATE_DEDICATED_SL_ACCOUNT_URI1. */
	public static final String CREATE_DEDICATED_SL_ACCOUNT_URI1 = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";

	/** The Constant NOTIFY_FILE_PATH. */
	public static final String NOTIFY_FILE_PATH = "src/com/rackspace/brm/account/templates/notify.json";

	/** The Constant FILL_A_BOX_SUCCESS_FILE_PATH. */
	public static final String FILL_A_BOX_SUCCESS_FILE_PATH = "src/com/rackspace/brm/account/templates/fill_a_box_success.json";

	/** The Constant GET_ACCOUNT. */
	public static final String GET_ACCOUNT = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts/$accountNumber";

	/** The Constant GET_ACCOUNT_PSL. */
	public static final String GET_ACCOUNT_PSL = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/flags";

}
