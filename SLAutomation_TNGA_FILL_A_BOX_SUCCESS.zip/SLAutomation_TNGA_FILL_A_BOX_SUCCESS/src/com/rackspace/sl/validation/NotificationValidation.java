package com.rackspace.sl.validation;

import com.rackspace.brm.common.Utils;
import com.rackspace.sl.event.model.Event;

/**
 * The Class NotificationValidation.
 */
public class NotificationValidation {

	/**
	 * Validate notification.
	 *
	 * @param accountNumber
	 *            the account number
	 * @param query
	 *            the query
	 * @return the event
	 */
	public static Event validateNotification(String accountNumber, String query) {

		String actualNotificationID = null;
		Event emailNotificationEvent = new Event();

		try {
			Utils.APP_LOGS.info("Enter: validateNotification()");

			actualNotificationID = Utils.retrieveDetailsFromBazookaDB(query, "%" + accountNumber + "%");

			/* Assert.assertNotNull(actualNotificationID); */

			System.out.println("actualNotificationID in validateNotification " + actualNotificationID);

			emailNotificationEvent.setNotificationID(actualNotificationID);

			Utils.APP_LOGS.info("Exit: validateNotification()");

		} catch (Exception e) {
			Utils.APP_LOGS.error("Notification can not be validates" + e);
		}
		return emailNotificationEvent;

	}

	/**
	 * Validate notification status.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @return the event
	 */
	public static Event validateNotificationStatus(Event emailNotificationEvent) {

		try {
			Utils.APP_LOGS.info("Enter: validateNotificationStatus()");
			/*
			 * Assert.assertEquals(emailNotificationEvent.getNotificationStatus(
			 * ), EventConstants.NotificationStatus.PENDING_STATUS.
			 * getNotificationStatus());
			 */

			Utils.APP_LOGS.info("Exit: validateNotificationStatus()");
		} catch (Exception e) {
			Utils.APP_LOGS.error("Notification can not be validates" + e);
		}
		return emailNotificationEvent;

	}

}
