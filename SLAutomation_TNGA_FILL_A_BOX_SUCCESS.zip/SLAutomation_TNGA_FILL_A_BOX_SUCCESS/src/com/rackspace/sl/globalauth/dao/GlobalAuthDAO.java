package com.rackspace.sl.globalauth.dao;

import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.rackspace.brm.common.Utils;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

/**
 * The Class GlobalAuthDAO.
 */
public class GlobalAuthDAO {

	/** The token. */
	String token;

	/**
	 * Instantiates a new global auth DAO.
	 */
	public GlobalAuthDAO() {
	}

	/**
	 * Gets the token.
	 *
	 * @param ipRBACprofile
	 *            the ip RBAc profile
	 * @return the token
	 * @throws Exception
	 *             the exception
	 */
	public RBACProfile getToken(RBACProfile ipRBACprofile) throws Exception {

		String inputStringXML = prepareAuthXMLString(ipRBACprofile);

		/*
		 * Response response =
		 * RestAPIConnectionExecutor.executeRestAPIConnection(inputStringXML,
		 * RBACProfileConstants.BSL_SYSTEM_ROLE_URL, SLConstants.POST,
		 * SLConstants.ACCEPT_APPLICATION_JSON,
		 * SLConstants.CONTENT_TYPE_APPLICATION_XML);
		 */

		System.out.println("################");

		Response response = RestAPIConnection.executeGetRestAPIConnectionPostWithToken(
				RBACProfileConstants.BSL_SYSTEM_ROLE_URL, SLConstants.ACCEPT_APPLICATION_JSON,
				SLConstants.CONTENT_TYPE_APPLICATION_XML, "", inputStringXML);

		System.out.println("################1212");

		RBACProfile rbacProfile = response.as(RBACProfile.class, ObjectMapperType.GSON);

		ipRBACprofile.setToken(rbacProfile.getAccess().getToken().getId());

		response.getStatusCode();

		Utils.createFile(inputStringXML, "Authentication_" + ipRBACprofile.getRbacProfileType() + ".xml");

		return ipRBACprofile;

	}

	/**
	 * Prepare auth XML string.
	 *
	 * @param ipRBACprofile
	 *            the ip RBA cprofile
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String prepareAuthXMLString(RBACProfile ipRBACprofile) throws Exception {

		String xmlTemplate = RBACProfileConstants.BSL_SYSTEM_ROLE_AUTH_XML;
		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			/* next, get the Template */
			Template template = velocityEngine.getTemplate(xmlTemplate);
			/* create a context and add data */
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("ROLEUSERNAME", ipRBACprofile.getBslUsername());
			velocityContext.put("ROLEAPIKEY", ipRBACprofile.getBslPassword());

			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		return writer.toString();

	}
}
