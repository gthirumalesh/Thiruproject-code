package com.rackspace.sl.event.dao;

import java.io.IOException;
import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.eclipse.jetty.http.HttpStatus;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.brm.account.constants.AccountConstants;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.parser.FListParser;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.constants.EventConstants;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.event.model.Notification;
import com.rackspace.sl.payment.constants.PaymentConstants;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

/**
 * The Class TemplateDAO.
 */
public class EventDAO {

	/** The input string json. */
	String inputStringJson = null;

	/**
	 * Gets the template ID.
	 *
	 * @param emailTemplateEvent
	 *            the email template event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the template ID
	 * @throws Exception
	 *             the exception
	 */
	public boolean getTemplateID(Event emailTemplateEvent, RBACProfile rbacProfile) throws Exception {

		String uri = EventConstants.GET_TEMPLATE_BY_ID.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				+ emailTemplateEvent.getTemplateType();
		System.out.println("========uri=======" + uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		System.out.println(response.getStatusCode());
		return (response.getStatusCode() == HttpStatus.OK_200);

	}

	/**
	 * Gets the template call.
	 *
	 * @param emailTemplateEvent
	 *            the email template event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the template call
	 * @throws Exception
	 *             the exception
	 */
	public int getTemplateCall(Event emailTemplateEvent, RBACProfile rbacProfile) throws Exception {

		String uri = EventConstants.GET_NOTIFICATION_URL
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$templateID", emailTemplateEvent.getTemplateID())
				.replace("$notificationID", emailTemplateEvent.getNotificationID());
		// System.out.println("========uri=======" + uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		Event eventRes = response.as(Event.class, ObjectMapperType.GSON);
		eventRes.setResponseCode(eventRes.getResponseCode());
		System.out.println(eventRes.getResponseCode());

		return eventRes.getResponseCode();

	}

	/**
	 * Publish event.
	 *
	 * @param opAccount
	 *            the op account
	 * @param emailTemplateEvent
	 *            the email template event
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 */
	public Account publishEvent(Account opAccount, Event emailTemplateEvent) throws Exception {

		Account account = null;

		System.out.println(
				"emailTemplateEvent.getTemplateType() in publish event " + emailTemplateEvent.getTemplateType());

		String inputStringFList = this.preparePublishEventFlistString(opAccount, emailTemplateEvent);
		System.out.println("**************inputStringFList************** \n" + inputStringFList);

		FList outputFList = OpcodeExecutor.executeOpcode(inputStringFList, BRMConstants.PCM_OP_PUBLISH_GEN_PAYLOAD);
		System.out.println("**************outputFList**************" + outputFList);

		account = FListParser.parseGenPayLoadOutputFlist(outputFList);

		System.out.println("account.getPayinfoList().get(0).getPaymentType()(())()()()()()()(())\n"
				+ account.getPayinfoList().get(0).getPaymentType());

		// Utils.createJsonFile(inputStringFList,
		// emailTemplateEvent.getTemplateType() + Utils.generateTenantId());
		return account;
	}

	/**
	 * Prepare publish event flist string.
	 *
	 * @param account
	 *            the account
	 * @param emailTemplateEvent
	 *            the email template event
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String preparePublishEventFlistString(Account account, Event emailTemplateEvent) throws Exception {

		String opcTemplate = null;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();
			Template template = null;
			VelocityContext velocityContext = null;

			if (emailTemplateEvent.getTemplateType().equals(EventConstants.TemplateType.NOTIFY.toString())) {

				opcTemplate = SLConstants.NOTIFY_FILE_PATH;
			}

			/* next, get the Template */
			template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			velocityContext = new VelocityContext();

			String[] accpoid = account.getAccountNumber().split("-");
			velocityContext.put("ACCOUNTPOID", accpoid[1]);
			velocityContext.put("PVT", account.getEndDate());
			velocityContext.put("ACCOUNTNUMBER", account.getAccountNumber());
			velocityContext.put("PAYTYPE", "1003");
			System.out.println("(account.getCurrency() " + account.getCurrency());
			if (account.getCurrency().equals(AccountConstants.Currency.USD.toString())) {
				System.out.println(" *********CURRENCYCODE*********** " + AccountConstants.Currency.USD.getCurrency());
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.USD.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.USD);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.USD.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.AUD.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.AUD.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.AUD);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.AUD.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.EUR.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.EUR.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.EUR);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.EUR.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.GBP.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.GBP.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.GBP);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.GBP.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.HKD.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.HKD.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.HKD);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.HKD.getcurrencySymbol());
			}
			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		// Utils.createFile(writer.toString(), "FList_" +
		// "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());

		System.out.println("Json Body " + writer.toString());
		return writer.toString();

	}

	/**
	 * Gets the notification ID.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the notification ID
	 * @throws Exception
	 *             the exception
	 */
	public Event getNotificationID(Event emailNotificationEvent, RBACProfile rbacProfile) throws Exception {

		String uri = EventConstants.GET_NOTIFICATION_URL
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$templateID", emailNotificationEvent.getTemplateType())
				.replace("$notificationID", emailNotificationEvent.getNotificationID());
		System.out.println("=====uri=====" + uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");

		Notification notificationJSONParser = response.as(Notification.class, ObjectMapperType.GSON);

		emailNotificationEvent.setNotificationStatus(notificationJSONParser.getRecipients().get(0).getStatus());
		System.out.println("Response Status Code : " + response.getStatusCode());
		Utils.APP_LOGS.info("Response Status Code : " + response.getStatusCode());
		return emailNotificationEvent;

	}

	/**
	 * Gets the notification.
	 *
	 * @param opAccount
	 *            the op account
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the notification
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the e buf exception
	 * @throws Exception
	 *             the exception
	 */
	public int getNotification(Account opAccount, Event emailNotificationEvent, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = PaymentConstants.GET_NOTIFICATION.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		Response response = RestAPIConnection.executeGetRestAPIConnectionMethodWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				opAccount.getAccountNumber(), "");

		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData***getsupportedResponseINPSL***" + response.getStatusCode());
		return response.getStatusCode();
	}

	/**
	 * Post notification ID.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the event
	 * @throws Exception
	 *             the exception
	 */
	public Event postNotificationID(Event emailNotificationEvent, RBACProfile rbacProfile) throws Exception {

		String inputStringJSON = prepareAuthXMLfile(emailNotificationEvent, rbacProfile);

		String uri = EventConstants.POST_NOTIFICATION_URL
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$templateID", emailNotificationEvent.getTemplateType());
		System.out.println("uri postNotification ID :" + uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionPostWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				inputStringJSON);

		Notification notificationJSONParser = response.as(Notification.class, ObjectMapperType.GSON);
		Event eventRes = response.as(Event.class, ObjectMapperType.GSON);

		emailNotificationEvent.setNotificationStatus(notificationJSONParser.getRecipients().get(0).getStatus());
		eventRes.setTemplateID(eventRes.getTemplateID());
		eventRes.setNotificationID(eventRes.getNotificationID());
		System.out.println("Notification ID : " + eventRes.getNotificationID());
		System.out.println("====================================================");
		System.out.println("StatusCode : " + response.getStatusCode());
		Utils.APP_LOGS.info("StatusCode : " + response.getStatusCode());

		return eventRes;

	}

	/**
	 * Prepare auth XM lfile.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String prepareAuthXMLfile(Event emailNotificationEvent, RBACProfile rbacProfile) throws Exception {

		String opcTemplate = SLConstants.FILL_A_BOX_SUCCESS_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put("EMAIL_BODY", emailNotificationEvent.getNotificationID());
			velocityContext.put("emailID", emailNotificationEvent.getTemplateID());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("FILL_A_BOX_SUCCES \n" + writer.toString());
		return writer.toString();

	}

	/**
	 * Gets the notification ID.
	 *
	 * @param accountNumber
	 *            the account number
	 * @param query
	 *            the query
	 * @return the notification ID
	 */
	public String getNotificationID(String accountNumber, String query) {

		String actualNotificationID = null;
		Event emailNotificationEvent = new Event();

		try {
			Utils.APP_LOGS.info("Enter: validateNotification()");

			actualNotificationID = Utils.retrieveDetailsFromBazookaDB(query, "%" + accountNumber + "%");

			System.out.println("actualNotificationID in validateNotification " + actualNotificationID);

			emailNotificationEvent.setNotificationID(actualNotificationID);

			Utils.APP_LOGS.info("Exit: validateNotification()");

		} catch (Exception e) {
			Utils.APP_LOGS.error("Notification can not be validates" + e);
		}
		return actualNotificationID;

	}

}