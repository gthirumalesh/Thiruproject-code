package com.rackspace.sl.event.action;

import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.Utils;
import com.rackspace.sl.event.dao.EventDAO;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

/**
 * The Class TemplateAction.
 */
public class EventAction {

	/**
	 * Gets the template by id.
	 *
	 * @param emailTemplateEvent
	 *            the email template event
	 * @param opRBACprofile
	 *            the op RBAc profile
	 * @return the template by id
	 * @throws Exception
	 *             the exception
	 */
	public boolean getTemplateById(Event emailTemplateEvent, RBACProfile opRBACprofile) throws Exception {

		EventDAO eventDAO = new EventDAO();
		eventDAO.getTemplateID(emailTemplateEvent, opRBACprofile);

		return true;
	}

	/**
	 * Gets the template id.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param opRBACprofile
	 *            the op RBA cprofile
	 * @return the template id
	 * @throws Exception
	 *             the exception
	 */
	public int getTemplateId(Event emailNotificationEvent, RBACProfile opRBACprofile) throws Exception {

		EventDAO eventDAO = new EventDAO();
		int reponse = eventDAO.getTemplateCall(emailNotificationEvent, opRBACprofile);

		return reponse;
	}

	/**
	 * Publish event.
	 *
	 * @param opAccount
	 *            the op account
	 * @param emailTemplateEvent
	 *            the email template event
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 */
	public Account publishEvent(Account opAccount, Event emailTemplateEvent) throws Exception {
		Account account = null;

		EventDAO eventDAO = new EventDAO();
		account = eventDAO.publishEvent(opAccount, emailTemplateEvent);
		return account;

	}

	/**
	 * Gets the notification.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param opRBACprofile
	 *            the op RBAc profile
	 * @return the notification
	 * @throws Exception
	 *             the exception
	 */
	public Event getNotification(Event emailNotificationEvent, RBACProfile opRBACprofile) throws Exception {
		EventDAO eventDAO;

		System.out.println("chk======== " + emailNotificationEvent.getEventtype() + " ====== "
				+ emailNotificationEvent.getNotificationID());

		Utils.APP_LOGS.info("chk======== " + emailNotificationEvent.getEventtype() + " ====== "
				+ emailNotificationEvent.getNotificationID());
		switch (emailNotificationEvent.getEventtype()) {
		case GET_NOTIFICATION:
			eventDAO = new EventDAO();
			emailNotificationEvent = eventDAO.getNotificationID(emailNotificationEvent, opRBACprofile);

			break;
		default:
			break;
		}

		return emailNotificationEvent;

	}

	/**
	 * Gets the notification by ID.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the notification by ID
	 * @throws Exception
	 *             the exception
	 */
	public Event getNotificationByID(Event emailNotificationEvent, RBACProfile rbacProfile) throws Exception {

		EventDAO eventDAO = new EventDAO();

		emailNotificationEvent = eventDAO.getNotificationID(emailNotificationEvent, rbacProfile);

		return emailNotificationEvent;
	}

	/**
	 * Post notification ID.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the event
	 * @throws Exception
	 *             the exception
	 */
	public Event postNotificationID(Event emailNotificationEvent, RBACProfile rbacProfile) throws Exception {
		EventDAO eventDAO = null;

		switch (emailNotificationEvent.getEventtype()) {
		case POST_NOTIFICATION:
			eventDAO = new EventDAO();
			emailNotificationEvent = eventDAO.postNotificationID(emailNotificationEvent, rbacProfile);
			break;
		default:
			break;

		}

		return emailNotificationEvent;

	}

	/**
	 * Gets the notification ID.
	 *
	 * @param accountNumber
	 *            the account number
	 * @param query
	 *            the query
	 * @return the notification ID
	 */
	public String getNotificationID(String accountNumber, String query) {

		EventDAO eventDAO = new EventDAO();
		String actualNotificationID = eventDAO.getNotificationID(accountNumber, query);
		return actualNotificationID;

	}

}
