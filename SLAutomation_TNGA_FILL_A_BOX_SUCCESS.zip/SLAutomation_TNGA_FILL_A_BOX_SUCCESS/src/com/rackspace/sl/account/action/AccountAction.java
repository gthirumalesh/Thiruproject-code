package com.rackspace.sl.account.action;

import java.io.IOException;

import org.json.JSONException;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.sl.account.dao.DedicatedAccountDAO;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.Utils;
import com.rackspace.sl.model.AcountParser;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

/**
 * The Class AccountAction is for business logic account action methods.
 */
public class AccountAction {

	/**
	 * Instantiates a new account action.
	 */

	/**
	 * Default constructor to instantiate an object
	 */
	public AccountAction() {

	}

	public Account createAccount(Account ipAccount, RBACProfile myRBACprofile) throws Exception {
		Account opAccount = null;
		switch (ipAccount.getAccountType()) {

		case DEDICATED:
			DedicatedAccountDAO dedicatedAccountSLDAO = new DedicatedAccountDAO();
			opAccount = dedicatedAccountSLDAO.createCustomerAccountInBRM(ipAccount, myRBACprofile);
			break;
		case USCLOUD:
			break;
		case UKCLOUD:
			break;
		}
		return opAccount;
	}

	/**
	 * Gets the SL account.
	 *
	 * @param ipAccount
	 *            the ip account
	 * @param myRBACprofile
	 *            the my RBA cprofile
	 * @return the SL account
	 * @throws Exception
	 *             the exception
	 */
	public int validateSLAccount(Account ipAccount, RBACProfile myRBACprofile) throws Exception {
		DedicatedAccountDAO dedicatedAccountDAO = new DedicatedAccountDAO();

		//dedicatedAccountDAO.getCustomerAccount(ipAccount, myRBACprofile);

		String accountNumber = ipAccount.getAccountNumber();
		System.out.println("acNo in AccountAction ========== : " + accountNumber);

		int response = dedicatedAccountDAO.getCustomerAccountInSL(ipAccount, myRBACprofile);
		System.out.println("AccountAction ==Account Number status code ==" + response);
		return response;
	}

	/**
	 * Creates the account BSLV 2.
	 *
	 * @param ipAccount
	 *            the ip account
	 * @param myRBACprofile
	 *            the my RBA cprofile
	 * @return the account
	 * @throws Exception
	 *             the exception
	 */
	/*
	 * public Account createAccountBSLV2(Account ipAccount, RBACProfile
	 * myRBACprofile) throws Exception { Account opAccount = null; switch
	 * (ipAccount.getAccountType()) {
	 * 
	 * case SLDEDICATED: DedicatedAccountDAO dedicatedAccountSLDAO = new
	 * DedicatedAccountDAO(); opAccount =
	 * dedicatedAccountSLDAO.createSLAccount(ipAccount, myRBACprofile); break;
	 * case US_CLOUD: break; case UK_CLOUD: break; } return opAccount; }
	 */
}
