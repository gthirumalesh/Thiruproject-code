package com.rackspace.brm.usage.model;

import com.rackspace.brm.usage.constants.UsageConstants.UsageType;

// TODO: Auto-generated Javadoc
/**
 * The Class DedicatedUsage.
 */
public class DedicatedUsage extends Usage {

	/** The tenant id. */
	String tenantId;
	
	/** The record id. */
	String recordId;
	
	/** The from date. */
	String fromDate;
	
	/** The end date. */
	String endDate;
	
	/** The month year. */
	String monthYear;
	
	/** The amount. */
	String amount;
	
	/** The record amount. */
	String recordAmount;
	
	/** The currency. */
	String currency;
	
	/**
	 * Instantiates a new dedicated usage.
	 */
	public DedicatedUsage() {
		// TODO Auto-generated constructor stub
		super(UsageType.DEDICATED);
	}

	/**
	 * Instantiates a new dedicated usage.
	 *
	 * @param tenantId the tenant id
	 * @param batchId the batch id
	 * @param recordId the record id
	 * @param fromDate the from date
	 * @param endDate the end date
	 * @param monthYear the month year
	 * @param amount the amount
	 * @param currency the currency
	 */
	public DedicatedUsage(String tenantId, String batchId, String recordId, String fromDate, String endDate,
			String monthYear, String amount, String currency) {
		// TODO Auto-generated constructor stub
		super(UsageType.DEDICATED);
		this.tenantId = tenantId;
		this.batchId = batchId;
		this.recordId = recordId;
		this.fromDate = fromDate;
		this.endDate = endDate;
		this.monthYear = monthYear;
		this.amount = amount;
		this.currency = currency;
	}

	/**
	 * Gets the tenant id.
	 *
	 * @return the tenant id
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * Sets the tenant id.
	 *
	 * @param tenantId the new tenant id
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/* (non-Javadoc)
	 * @see com.rackspace.brm.usage.model.Usage#getBatchId()
	 */
	public String getBatchId() {
		return batchId;
	}

	/* (non-Javadoc)
	 * @see com.rackspace.brm.usage.model.Usage#setBatchId(java.lang.String)
	 */
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	/**
	 * Gets the record id.
	 *
	 * @return the record id
	 */
	public String getRecordId() {
		return recordId;
	}

	/**
	 * Sets the record id.
	 *
	 * @param recordId the new record id
	 */
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	/* (non-Javadoc)
	 * @see com.rackspace.brm.usage.model.Usage#getFromDate()
	 */
	public String getFromDate() {
		return fromDate;
	}

	/* (non-Javadoc)
	 * @see com.rackspace.brm.usage.model.Usage#setFromDate(java.lang.String)
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/* (non-Javadoc)
	 * @see com.rackspace.brm.usage.model.Usage#getEndDate()
	 */
	public String getEndDate() {
		return endDate;
	}

	/* (non-Javadoc)
	 * @see com.rackspace.brm.usage.model.Usage#setEndDate(java.lang.String)
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the month year.
	 *
	 * @return the month year
	 */
	public String getMonthYear() {
		return monthYear;
	}

	/**
	 * Sets the month year.
	 *
	 * @param monthYear the new month year
	 */
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * Sets the amount.
	 *
	 * @param amount the new amount
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency the new currency
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the record amount.
	 *
	 * @return the record amount
	 */
	public String getRecordAmount() {
		return recordAmount;
	}

	/**
	 * Sets the record amount.
	 *
	 * @param recordAmount the new record amount
	 */
	public void setRecordAmount(String recordAmount) {
		this.recordAmount = recordAmount;
	}

}
