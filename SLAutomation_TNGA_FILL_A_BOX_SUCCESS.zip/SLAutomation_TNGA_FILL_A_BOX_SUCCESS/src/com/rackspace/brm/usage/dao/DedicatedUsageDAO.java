package com.rackspace.brm.usage.dao;

import org.apache.log4j.Logger;

import com.rackspace.brm.common.model.CommandObject;

// TODO: Auto-generated Javadoc
/**
 * The Class DedicatedUsageDAO.
 */
public class DedicatedUsageDAO {

	/**
	 * This method will read the usage model from Dedicated Usage class and
	 * prepare dedicated EBS usage file to be processed.
	 *
	 */
	/**
	 * The APP_LOGS used for capturing the message to be logged to the log file.
	 */
	public static Logger APP_LOGS = Logger.getLogger("LoggerName");
	
	/**
	 * Load dedicated usage.
	 *
	 * @param commandObject the command object
	 * @return the command object
	 */
	public CommandObject loadDedicatedUsage(CommandObject commandObject) {
		CommandObject opCommandObject = commandObject;
		
		return opCommandObject;
	}

}
