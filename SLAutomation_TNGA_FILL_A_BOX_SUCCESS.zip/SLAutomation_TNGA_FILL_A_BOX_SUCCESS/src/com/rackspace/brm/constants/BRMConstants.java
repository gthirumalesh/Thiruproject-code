package com.rackspace.brm.constants;

import java.util.*;

/**
 * The Class BRMConstants.
 */
public final class BRMConstants {

	/** The Constant PIN_ENVIRONMENT_USER. */
	// Constants variable for reading properties
	public static final String PIN_ENVIRONMENT_USER = "pinEnviornment";

	/** The Constant BRM_CM_LOG_DIR. */
	public static final String BRM_CM_LOG_DIR = "cmLogFromLocation";

	/** The Constant REPLACE_ENV_STRING. */
	public static final String REPLACE_ENV_STRING = "$env$";

	/** The Constant BRM_DM_LOG_DIR. */
	public static final String BRM_DM_LOG_DIR = "dmLogFromLocation";

	/** The Constant PVT_COMMAND_STRING. */
	public static final String PVT_COMMAND_STRING = "pvtCmd";

	/** The Constant SHELL_COMMAND. */
	public static final String SHELL_COMMAND = "shell";

	/** The Constant SUDO_COMMAND. */
	public static final String SUDO_COMMAND = "sudocommand";

	/** The Constant EXIT_NEWLINE. */
	public static final String EXIT_NEWLINE = "exit\n";

	/** The Constant SFTP. */
	public static final String SFTP = "sftp";

	/** The Constant PO_FLIST_NAP_FILE_NAME_LABEL. */
	// NAP FILE NAME KEYWORDS
	public static final String PO_FLIST_NAP_FILE_NAME_LABEL = "PO_Flist_RAX_OP_CUST_COMMIT_CUSTOMER.in.";

	/** The Constant PROGRAM_NAME. */
	public static final String PROGRAM_NAME = "TESTNG AUTOMATION";

	/** The Constant PAYMENT_OFFSET. */
	public static final String PAYMENT_OFFSET = "paymentOffset";

	/** The Constant BANK_NO. */
	public static final String BANK_NO = "bankNumber";

	/** The Constant BANK_CODE. */
	public static final String BANK_CODE = "bankCode";

	// Dedicated usage files

	/** The Constant EBS_BILLING_DAILY. */
	public static final String EBS_BILLING_DAILY = "EBS_BillingLinesdaily";

	/** The Constant EBS_BILLING_MONTHLY. */
	public static final String EBS_BILLING_MONTHLY = "EBS_BillingLinesmonthly";

	/** The Constant EBS_BILLING_FILE_EXTN. */
	public static final String EBS_BILLING_FILE_EXTN = ".csv";

	/** The Constant PDF_FILE_EXTN. */
	public static final String PDF_FILE_EXTN = ".pdf";

	/** The Constant PDF_FROM_LOCATION. */
	public static final String PDF_FROM_LOCATION = "pdfFromLocation";

	/** The Constant CONTACT_TYPE_PRIMARY. */
	public static final String CONTACT_TYPE_PRIMARY = "PRIMARY";

	/** The Constant CONTACT_TYPE_BILLING. */
	public static final String CONTACT_TYPE_BILLING = "BILLING";

	/** The Constant DEFAULT_ACCOUNT_NAMEINFO. */
	public static final String[] DEFAULT_ACCOUNT_NAMEINFO = { "San Antonio", "TX", "78258", "US" };

	/** This section to hold all opcode names. */

	public static final String CUSTOMER_CUST_COMMIT_OPCODE = "RAX_OP_CUST_COMMIT_CUSTOMER";

	/** The Constant RAX_OP_CUST_COMMIT_CUSTOMER. */
	public static final int RAX_OP_CUST_COMMIT_CUSTOMER = 100080;

	/** The Constant DEDICATED_PO_OPCODE. */
	public static final String DEDICATED_PO_OPCODE = "RAX_OP_CUST_ADD_SERVICE_BILLINFO";

	/** The Constant RAX_OP_CUST_MOVE_ACCOUNT. */
	public static final int RAX_OP_CUST_MOVE_ACCOUNT = 100251;

	/** The Constant INVOICE_TYPE_DEFAULT. */
	public static final String INVOICE_TYPE_DEFAULT = "default";

	/** The Constant INVOICE_TYPE_PO. */
	public static final String INVOICE_TYPE_PO = "pobill ";

	/** The Constant INVOICE_TYPE_STATEMENT. */
	public static final String INVOICE_TYPE_STATEMENT = "statement";

	/** The Constant RAX_INVOICE_QUERY. */
	public static final String RAX_INVOICE_QUERY = "raxInvoiceQuery";

	/** The Constant PCM_OP_PUBLISH_GEN_PAYLOAD. */
	public static final int PCM_OP_PUBLISH_GEN_PAYLOAD = 1301;

	/**
	 * This section to hold template name, file path etc.
	 */

	public static final String DEDICATED_ACCT_CREATE_OPC_FILE_PATH = "src/com/rackspace/brm/account/templates/RAX_OP_CUST_COMMIT_CUSTOMER_dedicated_CC.nap";

	/** The Constant CLOUD_ACCT_CREATE_OPC_FILE_PATH. */
	public static final String CLOUD_ACCT_CREATE_OPC_FILE_PATH = "yyy";

	/** The Constant DEDICATED_PO_CREATE_OPC_FILE_PATH. */
	public static final String DEDICATED_PO_CREATE_OPC_FILE_PATH = "zzz";

	/** Created for dedicated usage billing type. */
	public static final String DEDICATED_DAILY_BILLING_TYPE = "abc";

	/** The Constant DEDICATED_MONTHLY_BILLING_TYPE. */
	public static final String DEDICATED_MONTHLY_BILLING_TYPE = "def";

	/** The Constant DEDICATED_MONTHLY_USAGE_FILE_PATH. */
	public static final String DEDICATED_MONTHLY_USAGE_FILE_PATH = "src/com/rackspace/brm/usage/templates/EBS_BillingLines_Monthly_Usage.csv";

	/** The Constant DEDICATED_DAILY_USAGE_FILE_PATH. */
	public static final String DEDICATED_DAILY_USAGE_FILE_PATH = "src/com/rackspace/brm/usage/templates/EBS_BillingLines_Daily_Usage.csv";

	/** The Constant CURRENCY_SYMBOL_840. */
	public static final String CURRENCY_SYMBOL_840 = "$";

	/** The Constant CURRENCY_SYMBOL_826. */
	public static final String CURRENCY_SYMBOL_826 = "�";

	/** The Constant CURRENCY_SYMBOL_36. */
	public static final String CURRENCY_SYMBOL_36 = "$";

	/** The Constant CURRENCY_SYMBOL_978. */
	public static final String CURRENCY_SYMBOL_978 = "�";

	/** The Constant CURRENCY_SYMBOL_344. */
	public static final String CURRENCY_SYMBOL_344 = "$";

	/** The Constant isSuccessTrue. */
	public static final boolean isSuccessTrue = true;

	/** The Constant isSuccessFalse. */
	public static final boolean isSuccessFalse = false;

	/** The Constant FLIST_FOLDER_PATH_PROPERTY. */
	public static final String FLIST_FOLDER_PATH_PROPERTY = "fListFolderPath";

	/** The Constant CSV_FOLDER_PATH_PROPERTY. */
	public static final String CSV_FOLDER_PATH_PROPERTY = "csvFolderPath";

	/** The Constant USAGE_FOLDER_PATH_PROPERTY. */
	public static final String USAGE_FOLDER_PATH_PROPERTY = "usageFolderPath";

	/** The Constant PDF_FOLDER_PATH_PROPERTY. */
	public static final String PDF_FOLDER_PATH_PROPERTY = "pdfFolderPath";

	/** The Constant GL_FOLDER_PATH_PROPERTY. */
	public static final String GL_FOLDER_PATH_PROPERTY = "glFolderPath";

	/** The Constant CMLOGS_FOLDER_PATH_PROPERTY. */
	public static final String CMLOGS_FOLDER_PATH_PROPERTY = "cmlogsFolderPath";

	/** The Constant DMLOGS_FOLDER_PATH_PROPERTY. */
	public static final String DMLOGS_FOLDER_PATH_PROPERTY = "dmlogsFolderPath";

	/** The Constant TAXLOGS_FOLDER_PATH_PROPERTY. */
	public static final String TAXLOGS_FOLDER_PATH_PROPERTY = "taxlogsFolderPath";

	/** The Constant JSON_FOLDER_PATH_PROPERTY. */
	public static final String JSON_FOLDER_PATH_PROPERTY = "jsonFolderPath";

	/** The Constant XML_FOLDER_PATH_PROPERTY. */
	public static final String XML_FOLDER_PATH_PROPERTY = "xmlFolderPath";

	/** The Constant HTML_FOLDER_PATH_PROPERTY. */
	public static final String HTML_FOLDER_PATH_PROPERTY = "htmlFolderPath";

	/**
	 * This section to hold all enumerators.
	 */

	public enum AccountType {

		/** The dedicated. */
		DEDICATED,
		/** The cloud. */
		CLOUD
	}

	/**
	 * The Enum BillingType.
	 */
	public enum BillingType {

		/** The daily billing. */
		DAILY_BILLING,
		/** The monthly billing. */
		MONTHLY_BILLING,
	}

	/**
	 * The Enum PaymentType.
	 */
	public enum PaymentType {

		/** The cc. */
		CC,
		/** The ach dd. */
		ACH_DD,
		/** The ukdd. */
		UKDD,
		/** The nlsepa. */
		NLSEPA
	}

	/**
	 * Currency symbol.
	 *
	 * @param currency
	 *            the currency
	 * @return the string
	 */
	public static String currencySymbol(String currency) {

		HashMap<String, String> CURRENCY_SYMBOL = new HashMap<String, String>();

		CURRENCY_SYMBOL.put("840", "$");
		CURRENCY_SYMBOL.put("826", "�");
		CURRENCY_SYMBOL.put("36", "$");
		CURRENCY_SYMBOL.put("978", "�");
		CURRENCY_SYMBOL.put("344", "$");

		String value = (String) CURRENCY_SYMBOL.get(currency);

		return value;

	}
}
