package com.rackspace.brm.account.dao;

import com.portal.pcm.FList;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;

/**
 * The Class CloudAccountDAO.
 * 
 */
public class CloudAccountDAO {
	/**
	 * The cloudAccount reference of the CloudAccountOld class object
	 */
	protected Account cloudAccount = null;

	/**
	 * Instantiates a new cloud account DAO.
	 */
	public CloudAccountDAO() {
	}

	/**
	 * Instantiates a new cloud account DAO.
	 *
	 * @param cloudAccount
	 *            the cloud account
	 */
	public CloudAccountDAO(Account cloudAccount) {
		this.cloudAccount = cloudAccount;
	}

	/**
	 * Creates the account.
	 *
	 * @return the f list
	 */
	public FList createAccount() {
		FList opFlist = OpcodeExecutor.executeOpcode(this.buildInputFlist(), BRMConstants.CUSTOMER_CUST_COMMIT_OPCODE);
		return opFlist;
	}

	/**
	 * Update account.
	 *
	 * @return the FList
	 */
	public FList updateAccount() {
		return null;
	}

	/**
	 * This method to build input FList by using the value from Cloud Account
	 * value object and opcode template file.
	 *
	 * @return the inputFlist
	 */
	private FList buildInputFlist() {
		String opcTemplate = BRMConstants.CLOUD_ACCT_CREATE_OPC_FILE_PATH;
		FList inputFlist = null;
		return inputFlist;
	}

}
