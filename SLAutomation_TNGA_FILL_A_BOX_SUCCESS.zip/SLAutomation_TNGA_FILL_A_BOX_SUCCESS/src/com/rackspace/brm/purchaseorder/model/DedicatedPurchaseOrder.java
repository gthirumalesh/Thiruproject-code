package com.rackspace.brm.purchaseorder.model;

import com.rackspace.brm.purchaseorder.constants.PurchaseOrderType;

/**
 * The Class DedicatedPurchaseOrder.
 */
public class DedicatedPurchaseOrder extends PurchaseOrder {

	/** The PVT represents the PVT variable */
	private String pvt = null;

	/** The tenantId represents the tenantId variable */
	private String tenantId = null;

	/** The accountNumber represents the accountNumber variable */
	private String accountNumber = null;

	/**
	 * Instantiates a new dedicated purchase order.
	 */
	public DedicatedPurchaseOrder() {
		super(PurchaseOrderType.DEDICATED);
	}

	/**
	 * Gets the PVT.
	 *
	 * @return the PVT
	 */
	public String getPvt() {
		return pvt;
	}

	/**
	 * Sets the PVT.
	 *
	 * @param pvt
	 *            used to set the new PVT
	 */
	public void setPvt(String pvt) {
		this.pvt = pvt;
	}

	/**
	 * Gets the tenant id.
	 *
	 * @return the tenant id
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * Sets the tenant id.
	 *
	 * @param tenantId
	 *            used to set the new tenant id
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @see com.rackspace.brm.purchaseorder.model.PurchaseOrder#getAccountNumber()
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @see com.rackspace.brm.purchaseorder.model.PurchaseOrder#setAccountNumber(java.lang.String)
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Instantiates a new dedicated purchase order.
	 *
	 * @param purchaseOrderType
	 *            reference of the PurchaseOrderType
	 * @param pvt
	 *            the used to store the PVT
	 * @param tenantId
	 *            used to store the tenantId
	 */
	public DedicatedPurchaseOrder(PurchaseOrderType purchaseOrderType, String pvt, String tenantId) {
		super(PurchaseOrderType.DEDICATED);

		this.pvt = pvt;
		this.tenantId = tenantId;
	}

}
