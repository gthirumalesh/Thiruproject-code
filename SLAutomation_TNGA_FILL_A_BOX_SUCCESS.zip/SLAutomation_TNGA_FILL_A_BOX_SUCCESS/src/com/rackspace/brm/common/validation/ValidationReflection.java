package com.rackspace.brm.common.validation;

import java.lang.reflect.Method;

public class ValidationReflection {

	ValidationReflection() {

	}

	/**
	 * Gets value from object using reflection.
	 * 
	 * @param object
	 *            the object
	 * @param fieldName
	 *            the field
	 * @return the value
	 * @throws Exception
	 */
	public static String getAttributeValueFromObject(Object object, String fieldName) throws Exception {

		// get class
		Class<? extends Object> clazz = object != null ? object.getClass() : null;
		if (clazz == null) {
			return null;
		}

		// get object value using reflection
		String getterName = "get" + fieldName;
		try {
			Method method = clazz.getMethod(getterName);
			Object valueObject = method.invoke(object, (Object[]) null);
			return valueObject != null ? valueObject.toString() : "";
		} catch (Exception e) {
			// ignore all reflection errors
			throw e;
		}
	}

}
