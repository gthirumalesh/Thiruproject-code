package com.rackspace.brm.validation;

import org.testng.Assert;

import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;

public class InvoiceValidation {

	public static void validateInvoiceObject(String billNumber) throws Exception {

		try {
			Utils.APP_LOGS.info("Enter:InvoiceValidation()");

			String invoiceObjectID = Utils.retrieveDetailsFromDB("invoiceQuery", billNumber);
			long invoiceValue = Long.parseLong(invoiceObjectID);

			// System.out.println("invoiceObjectID: " + invoiceObjectID);

			long raxInvoiceDefaultValue = Long
					.parseLong(PropertyUtil.getCommonProperties().getProperty("raxInvoiceDefaultValue"));

			if (invoiceValue > 0 && invoiceValue != raxInvoiceDefaultValue) {

				Assert.assertNotNull(invoiceValue);

			} else {
				Assert.fail("InvoiceObject  is  not been generated");
			}

		} catch (Exception e) {
			Utils.APP_LOGS.error("Invoice Object can not be validate" + e);
		}

		Utils.APP_LOGS.info("Exit:InvoiceValidation()");

	}

	public static void validateHierarchicalAccountInvoiceObject(String query, String billNumber) throws Exception {

		try {
			Utils.APP_LOGS.info("Enter:validateHierarchicalAccountInvoiceObject()");

			String invoiceObjectID = Utils.retrieveDetailsFromDB("invoiceQuery", billNumber);
			long invoiceValue = Long.parseLong(invoiceObjectID);

			// long
			// raxInvoiceDefaultValue=Long.parseLong(PropertyUtil.getCommonProperties().getProperty("raxInvoiceDefaultValue"));

			if (invoiceValue > 0) {

				Assert.assertNotNull(invoiceValue);

			} else {
				Assert.fail("InvoiceObject  is  not been generated hierarchicalAccount");
			}

		} catch (Exception e) {
			Utils.APP_LOGS.error("Invoice Object can not be validate for hierarchicalAccount" + e);
		}

		Utils.APP_LOGS.info("Exit:validateHierarchicalAccountInvoiceObject");

	}
}
