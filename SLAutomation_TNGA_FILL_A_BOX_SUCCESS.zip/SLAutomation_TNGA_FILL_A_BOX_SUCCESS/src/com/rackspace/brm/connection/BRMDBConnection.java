package com.rackspace.brm.connection;

import java.sql.Connection;
import java.sql.DriverManager;

import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;

public class BRMDBConnection extends BaseConnection {

	public static Connection connection = null;
	private static volatile boolean isInitialized = false;

	protected BRMDBConnection() {
	}

	public static synchronized Connection getBRMDBConnection() throws Exception {

		if (!isInitialized) {

			String sDBHost = PropertyUtil.getCommonProperties().getProperty("sDBHost");
			String sDBUser = PropertyUtil.getCommonProperties().getProperty("sDBUser");
			String sDBPwd = PropertyUtil.getCommonProperties().getProperty("sDBPwd");
			String sDBSid = PropertyUtil.getCommonProperties().getProperty("sDBSid");
			String port = PropertyUtil.getCommonProperties().getProperty("port");

			// load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// create the connection object
			connection = DriverManager.getConnection("jdbc:oracle:thin:@" + sDBHost + ":" + port + ":" + sDBSid,
					sDBUser, sDBPwd);
			Utils.APP_LOGS.info("BRM DB Connection is established"+ connection);
			isInitialized = true;
		}
		return connection;
	}
	
	
	

}
