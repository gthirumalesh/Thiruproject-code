package com.rackspace.zproject.zlombok;



public class GetterSetterMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GetterSetterSubClass getterSetterSubClass = new GetterSetterSubClass();
		
		//getterSetterSubClass.setI(10);

	}

}
