
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class Payment.
 */
public class Payment {

    /** The method. */
    @SerializedName("method")
    @Expose
    private Method method;
   /* @SerializedName("paymentResponse")
    @Expose
    private PaymentResponse paymentResponse;
    */

    /**
    * Gets the method.
    *
    * @return the method
    */
   public Method getMethod() {
        return method;
    }

    /**
     * Sets the method.
     *
     * @param method the new method
     */
    public void setMethod(Method method) {
        this.method = method;
    }

/*	public PaymentResponse getPaymentResponse() {
		return paymentResponse;
	}

	public void setPaymentResponse(PaymentResponse paymentResponse) {
		this.paymentResponse = paymentResponse;
	}*/

}
