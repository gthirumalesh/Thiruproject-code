
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentCardRespone.
 */
public class PaymentCardRespone {

    /** The card holder name. */
    @SerializedName("cardHolderName")
    @Expose
    private String cardHolderName;
    
    /** The card number. */
    @SerializedName("cardNumber")
    @Expose
    private String cardNumber;
    
    /** The expiration date. */
    @SerializedName("expirationDate")
    @Expose
    private String expirationDate;
    
    /** The card type. */
    @SerializedName("cardType")
    @Expose
    private String cardType;
    
    /** The level 3 eligible. */
    @SerializedName("level3Eligible")
    @Expose
    private Boolean level3Eligible;

    /**
     * Gets the card holder name.
     *
     * @return the card holder name
     */
    public String getCardHolderName() {
        return cardHolderName;
    }

    /**
     * Sets the card holder name.
     *
     * @param cardHolderName the new card holder name
     */
    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    /**
     * Gets the card number.
     *
     * @return the card number
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the card number.
     *
     * @param cardNumber the new card number
     */
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    /**
     * Gets the expiration date.
     *
     * @return the expiration date
     */
    public String getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the expiration date.
     *
     * @param expirationDate the new expiration date
     */
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    /**
     * Gets the card type.
     *
     * @return the card type
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Sets the card type.
     *
     * @param cardType the new card type
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    /**
     * Gets the level 3 eligible.
     *
     * @return the level 3 eligible
     */
    public Boolean getLevel3Eligible() {
        return level3Eligible;
    }

    /**
     * Sets the level 3 eligible.
     *
     * @param level3Eligible the new level 3 eligible
     */
    public void setLevel3Eligible(Boolean level3Eligible) {
        this.level3Eligible = level3Eligible;
    }

}
