package com.rackspace.sl.payment.action;

import com.rackspace.brm.account.model.Account;
import com.rackspace.sl.payment.dao.PaymentDAO;
import com.rackspace.sl.payment.model.PaymentCard;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentAction.
 */
public class PaymentAction {

    /** The ip payment card. */
    PaymentCard ipPaymentCard=null;
	
	/**
	 * Creates the CC method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param ipRBACprofile the ip RBA cprofile
	 * @param ipAccount the ip account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	public PaymentCard createCCMethod(PaymentCard ipPaymentCard, RBACProfile ipRBACprofile, Account ipAccount)
			throws Exception {

		switch (ipPaymentCard.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPaymentCard = paymentDAO.createCCMethod(ipPaymentCard,ipRBACprofile, ipAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPaymentCard;
	}

	/**
	 * Creates the get supported method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param ipRBACprofile the ip RBA cprofile
	 * @param opAccount the op account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	public PaymentCard createGetSupportedMethod(PaymentCard ipPaymentCard, RBACProfile ipRBACprofile,
			Account opAccount) throws Exception {

		switch (ipPaymentCard.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPaymentCard = paymentDAO.getSupportedMethod(ipPaymentCard, ipRBACprofile, opAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPaymentCard;
	}

	/**
	 * Creates the default method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param ipRBACprofile the ip RBA cprofile
	 * @param ipAccount the ip account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	public PaymentCard createDefaultMethod(PaymentCard ipPaymentCard, RBACProfile ipRBACprofile, Account ipAccount)
			throws Exception {

		switch (ipPaymentCard.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPaymentCard = paymentDAO.doPutDefaultMethod(ipPaymentCard, ipRBACprofile, ipAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPaymentCard;
	}

	/**
	 * Creates the get default method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param ipRBACprofile the ip RBA cprofile
	 * @param opAccount the op account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	public PaymentCard createGetDefaultMethod(PaymentCard ipPaymentCard, RBACProfile ipRBACprofile,
			Account opAccount) throws Exception {

		switch (ipPaymentCard.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPaymentCard = paymentDAO.setGetDefaultMethod(ipPaymentCard, ipRBACprofile, opAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPaymentCard;
	}

	/**
	 * Validate PSL account.
	 *
	 * @param opAccount the op account
	 * @param myRBACprofile the my RBA cprofile
	 * @return the int
	 * @throws Exception the exception
	 */
	public int validatePSLAccount(Account opAccount, RBACProfile myRBACprofile) throws Exception {

		PaymentDAO paymentDAO = new PaymentDAO();

		// paymentdao.getCustomerAccount2(ipAccount, myRBACprofile);

		String accountNumber = opAccount.getAccountNumber();
		System.out.println("accountNumber in AccountAction ===validatePSLAccount=== " + accountNumber);

		int reponse = paymentDAO.getCustomerAccountInPSL(opAccount, myRBACprofile);

		return reponse;
	}

	/*
	 * validate responsecode in CreateCCMethod
	 */

	/**
	 * Validate CC method.
	 *
	 * @param ipRBACProfile the ip RBAC profile
	 * @param opAccount the op account
	 * @return the int
	 * @throws Exception the exception
	 */
	public int validateCCMethod(RBACProfile ipRBACProfile, Account opAccount)
			throws Exception {

		PaymentDAO paymentDAO = new PaymentDAO();

		//paymentdao.getCustomerAccountCC(ipPaymentCard, ipRBACProfile, opAccount);

		String accountNumber = opAccount.getAccountNumber();
		System.out.println("accountNumber in AccountAction===validateACHMethod=== : " + accountNumber);

		int reponse = paymentDAO.validateCCMethod(ipRBACProfile, opAccount);

		return reponse;
	}

	/**
	 * Validate set default method.
	 *
	 * @param opPaymentCard the op payment card
	 * @param myRBACprofile the my RBA cprofile
	 * @param opAccount the op account
	 * @return the int
	 * @throws Exception the exception
	 */
	/*
	 * Set Default Method
	 */
	public int validateSetDefaultMethod(PaymentCard opPaymentCard, RBACProfile myRBACprofile,Account opAccount) throws Exception {

		PaymentDAO paymentDAO = new PaymentDAO();

		// paymentdao.getCustomerAccount1(ipAccount, myRBACprofile);

		String accountNumber = opAccount.getAccountNumber();
		System.out
				.println("accountNumber in AccountAction===validatePSLSetDefaultMethodResponse=== : " + accountNumber);

        int response = paymentDAO.validateSetDefaultMethod(opPaymentCard,opAccount, myRBACprofile);
		return response;
	}

	/*
	 * validate response code in getSupported method
	 */

	/**
	 * Validate get supported method.
	 *
	 * @param opAccount the op account
	 * @param myRBACprofile the my RBA cprofile
	 * @return the int
	 * @throws Exception the exception
	 */
	public int validateGetSupportedMethod(Account opAccount, RBACProfile myRBACprofile) throws Exception {

		PaymentDAO paymentDAO = new PaymentDAO();

		// paymentdao.getCustomerAccount(opAccount, myRBACprofile);

		String accountNumber = opAccount.getAccountNumber();
		System.out.println("accountNumber in validateGetSupportedMethod : " + accountNumber);

		int reponse = paymentDAO.validateGetSupportMethod(opAccount, myRBACprofile);

		return reponse;
	}



	/**
	 * Validate get default method.
	 *
	 * @param opPaymentCard the op payment card
	 * @param myRBACprofile the my RBA cprofile
	 * @param opAccount the op account
	 * @return the int
	 * @throws Exception the exception
	 */
	public int validateGetDefaultMethod(PaymentCard opPaymentCard,RBACProfile myRBACprofile,Account opAccount) throws Exception {

		PaymentDAO paymentDAO = new PaymentDAO();

		// paymentdao.getCustomerAccount(opAccount, myRBACprofile);

		String accountNumber = opAccount.getAccountNumber();
		System.out.println("accountNumber in validateGetDefaultMethod : " + accountNumber);

		int reponse = paymentDAO.validateGetDefaultMethod(opPaymentCard, myRBACprofile,opAccount);

		return reponse;
	}

}
