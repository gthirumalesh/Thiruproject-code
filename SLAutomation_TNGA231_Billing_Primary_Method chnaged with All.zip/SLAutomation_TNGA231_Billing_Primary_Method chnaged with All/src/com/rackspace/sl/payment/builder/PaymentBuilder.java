package com.rackspace.sl.payment.builder;

import com.rackspace.sl.payment.constants.PaymentConstants.CardTypes;
import com.rackspace.sl.payment.model.PaymentCard;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentBuilder.
 */
public class PaymentBuilder {
	
	/** The payments. */
	PaymentCard payments = null;

	/**
	 * Instantiates a new payment builder.
	 *
	 * @param cardTypes the card types
	 * @param cardVerificationNumber the card verification number
	 * @param cardHolderName the card holder name
	 * @param cardNumber the card number
	 * @param expireDate the expire date
	 * @param cardType the card type
	 */
	public PaymentBuilder(CardTypes cardTypes, String cardVerificationNumber,String cardHolderName, String cardNumber, String expireDate,String cardType) {

		payments = new PaymentCard();
		payments.setCardHolderName(cardHolderName);
		payments.setCardNumber(cardNumber);
		payments.setCardVerificationNumber(cardVerificationNumber); 
		payments.setCardTypes(cardTypes);
		payments.setCardType(cardType);
		payments.setExpirationDate(expireDate);
	

	}

	/**
	 * Gets the payments.
	 *
	 * @return the payments
	 */
	public PaymentCard getPayments() {
		return payments;
	}


}

