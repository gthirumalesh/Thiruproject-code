package com.rackspace.sl.constants;

/**
 * The Class SLConstants.
 */
public class SLConstants {

	/** The Constant POST. */
	public static final String POST = "POST";
	
	/** The Constant GET. */
	public static final String GET = "GET";
	
	/** The Constant ACCEPT_APPLICATION_JSON. */
	public static final String ACCEPT_APPLICATION_JSON = "application/json";
	
	/** The Constant CONTENT_TYPE_APPLICATION_JSON. */
	public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
	
	/** The Constant ACCEPT_APPLICATION_XML. */
	public static final String ACCEPT_APPLICATION_XML = "application/xml";
	
	/** The Constant CONTENT_TYPE_APPLICATION_XML. */
	public static final String CONTENT_TYPE_APPLICATION_XML = "application/xml";
	
	/** The Constant ENVIORNMENT. */
	public static final String ENVIORNMENT = "enviornment";
	public static final String BSLV2_NOTIFICATION_QUERY="bslv2notificationQuery";
	
	/** The Constant NOTIFICATION_QUERY. */
	public static final String NOTIFICATION_QUERY = "notificationQuery";
	
	public static final String BSL_NOTIFICATION_QUERY="bslvatnotificationQuery";
	
	/** The Constant DEDICATED_ACCT_CREATE_JSON_FILE_PATH. */
	public static final String DEDICATED_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/CreateDedicatedUSAccount.json";
	public static final String US_CLOUD_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/createUSCLOUDAccount.json";
	public static final String UK_CLOUD_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/UK_CLOUDJSONFILE.json";
	
	public static final String CREATE_ACH_METHOD_FILE_PATH ="src/com/rackspace/brm/account/templates/CreateAchUSAccount.json";
	
	public static final String CREATE_CC_METHOD_FILE_PATH ="src/com/rackspace/brm/account/templates/createCCMethod.json";
	
		
	public static final String SET_DEFAULT_ACH_FILE_PATH="src/com/rackspace/brm/account/templates/SetDefaultMethodACH.json";
	
	public static final String SET_DEFAULT_PAYMENT_METHOD_FILE_PATH="src/com/rackspace/brm/account/templates/SetDefaultMethodCC.json";
    /* The Constant CREATE_DEDICATED_SL_ACCOUNT_URI. */
	public static final String CREATE_DEDICATED_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";
	public static final String CREATE_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";
	public static final String CREATE_UK_CLOUD_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";
	
	
	/** The Constant GET_ACCOUNT. */
	public static final String GET_ACCOUNT="https://$env.billingv2.api.rackspacecloud.com/v2/accounts/$accountNumber";
	
	
	public static final String GET_ACCOUNT_PSL = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/flags";
	
	
}
