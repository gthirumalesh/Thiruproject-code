package com.rackspace.sl.constants;


public final class  AccountConstants  {
	
	/** The Constant DEDICATED_ACCOUNT_PREFIX. */
	public static final String DEDICATED_ACCOUNT_PREFIX = "030-";
    public static final String US_CLOUD_ACCOUNT_PREFIX = "020-";
    public static final String UK_CLOUD_ACCOUNT_PREFIX = "021-";

	
	
	

}
