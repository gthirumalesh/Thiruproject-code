package com.rackspace.sl.event.dao;

import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.eclipse.jetty.http.HttpStatus;
import org.json.JSONObject;

import com.portal.pcm.FList;
import com.rackspace.brm.account.constants.AccountConstants;
import com.rackspace.brm.account.constants.AccountConstants.BillingSegment;
import com.rackspace.brm.account.constants.AccountConstants.Currency;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.parser.FListParser;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.constants.EventConstants;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.event.model.Notification;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;


/**
 * The Class TemplateDAO.
 */
public class EventDAO {

	/** The input string json. */
	String inputStringJson = null;

	/**
	 * Gets the template ID.
	 *
	 * @param emailTemplateEvent
	 *            the email template event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the template ID
	 * @throws Exception
	 *             the exception
	 */
	public boolean getTemplateID(Event emailTemplateEvent, RBACProfile rbacProfile) throws Exception {

		String uri = EventConstants.GET_TEMPLATE_BY_ID.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				+ emailTemplateEvent.getTemplateType();
		System.out.println("========================");
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");

		return (response.getStatusCode() == HttpStatus.OK_200);

	}

	/**
	 * Publish event.
	 *
	 * @param opAccount
	 *            the op account
	 * @param emailTemplateEvent
	 *            the email template event
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 */
	public Account publishEvent(Account opAccount, Event emailTemplateEvent) throws Exception {

		Account account = null;
        System.out.println(
                "emailTemplateEvent.getTemplateType() in publish event " + emailTemplateEvent.getTemplateType());
     String fListFolderPath = PropertyUtil.getCommonProperties()
                .getProperty(BRMConstants.FLIST_FOLDER_PATH_PROPERTY);

		String inputStringFList = this.preparePublishEventFlistString(opAccount, emailTemplateEvent);
		System.out.println("**************inputStringFList************** \n" + inputStringFList);

		FList outputFList = OpcodeExecutor.executeOpcode(inputStringFList, BRMConstants.PCM_OP_PUBLISH_GEN_PAYLOAD);
		System.out.println("**************outputFList**************" + outputFList);

		account = FListParser.parseGenPayLoadOutputFlist(outputFList);

		System.out.println("account.getPayinfoList().get(0).getPaymentType()(())()()()()()()(())\n"
				+ account.getPayinfoList().get(0).getPaymentType());
		return account;
	}

	/**
	 * Prepare publish event flist string.
	 *
	 * @param account
	 *            the account
	 * @param emailTemplateEvent
	 *            the email template event
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String preparePublishEventFlistString(Account account, Event emailTemplateEvent) throws Exception {

		String opcTemplate = null;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();
			Template template = null;
			VelocityContext velocityContext = null;

			if (emailTemplateEvent.getTemplateType()
					.equals(EventConstants.TemplateType.BILLING_PRIMARY_METHOD_CHANGED.toString())) {

				opcTemplate = BRMConstants.BILLING_PRIMARY_METHOD_CHANGED_FILE_PATH;

			} else if (emailTemplateEvent.getTemplateType()
					.equals(EventConstants.TemplateType.BILLING_PAYMENT_SUCCESS_CC.toString())) {

				opcTemplate = BRMConstants.BILLING_PAYMENT_SUCCESS_CC_FILE_PATH;
			}else if (emailTemplateEvent.getTemplateType()
					.equals(EventConstants.TemplateType.BILLING_PREDRAFT_NOTIFICATION.toString())) {

				opcTemplate = BRMConstants.BILLING_PREDRAFT_NOTIFICATION_FILE_PATH;
			
			
		}else if (emailTemplateEvent.getTemplateType()
				.equals(EventConstants.TemplateType.BILLING_PROBLEM_CHARGE_CC.toString())) {

			opcTemplate = BRMConstants.BILLING_PROBLEM_CHARGE_CC_FILE_PATH;
		}else if (emailTemplateEvent.getTemplateType()
				.equals(EventConstants.TemplateType.BILLING_PROBLEM_CHARGE_ACH.toString())) {

			opcTemplate = BRMConstants.BILLING_PROBLEM_CHARGE_CC_FILE_PATH;
		}
		else if (emailTemplateEvent.getTemplateType()
				.equals(EventConstants.TemplateType.BILLING_EXPIRY_CC.toString())) { 

			opcTemplate = BRMConstants.BILLING_EXPIRY_CC_FILE_PATH;
		}else if (emailTemplateEvent.getTemplateType()
				.equals(EventConstants.TemplateType.SPEND_THRESHOLD_LIMIT.toString())) {

			opcTemplate = BRMConstants.SPEND_THRESHOLD_LIMIT_FILE_PATH;
		}	
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/* next, get the Template */
			template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			velocityContext = new VelocityContext();

			String[] accpoid = account.getAccountNumber().split("-");
			velocityContext.put("ACCOUNTPOID", accpoid[1]);
			velocityContext.put("PVT", account.getEndDate());
			velocityContext.put("ACCOUNTNUMBER", account.getAccountNumber());
			velocityContext.put("PAYTYPE", "1003");
			System.out.println("(account.getCurrency() " + account.getCurrency());
			if (account.getCurrency().equals(AccountConstants.Currency.USD.toString())) {
				System.out.println(" *********CURRENCYCODE*********** " + AccountConstants.Currency.USD.getCurrency());
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.USD.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.USD);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.USD.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.AUD.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.AUD.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.AUD);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.AUD.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.EUR.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.EUR.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.EUR);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.EUR.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.GBP.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.GBP.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.GBP);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.GBP.getcurrencySymbol());
			} else if (account.getCurrency().equals(AccountConstants.Currency.HKD.toString())) {
				velocityContext.put("CURRENCYCODE", AccountConstants.Currency.HKD.getCurrency());
				velocityContext.put("CURRENCYNAME", AccountConstants.Currency.HKD);
				velocityContext.put("CURRENCYSYMBOL", AccountConstants.CurrencySymbol.HKD.getcurrencySymbol());
			}
			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		// Utils.createFile(writer.toString(), "FList_" +
		// "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());
		System.out.println(emailTemplateEvent.getTemplateType() +" \n" + writer.toString());
		return writer.toString();

	}

	/**
	 * Gets the notification ID.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param rbacProfile
	 *            the rbac profile
	 * @return the notification ID
	 * @throws Exception
	 *             the exception
	 */
	public Event getNotificationID(Event emailNotificationEvent, RBACProfile rbacProfile) throws Exception {
		String uri = EventConstants.GET_NOTIFICATION_URL.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		uri = uri.replace("$templateID", emailNotificationEvent.getTemplateType());
		uri = uri.replace("$notificationID", emailNotificationEvent.getNotificationID());

		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");

		Notification notificationJSONParser = response.as(Notification.class, ObjectMapperType.GSON);

		System.out.println("notificationJSONParser.getRecipients().get(0).getStatus() "
				+ notificationJSONParser.getRecipients().get(0).getStatus());

		emailNotificationEvent.setNotificationStatus(notificationJSONParser.getRecipients().get(0).getStatus());
		return emailNotificationEvent;

	}

	/**
	 * Gets the notification ID.
	 *
	 * @param accountNumber
	 *            the account number
	 * @param query
	 *            the query
	 * @return the notification ID
	 */
	public String getNotificationID(String accountNumber, String query) {

		String actualNotificationID = null;
		Event emailNotificationEvent = new Event();

		try {
			Utils.APP_LOGS.info("Enter: validateNotification()");
			Thread.sleep(4000);
			System.out.println(accountNumber);
			
			String accountTypeIdentifier[]=accountNumber.split("-");
			System.out.println(accountTypeIdentifier.length);
			if(accountTypeIdentifier.length>0){
				if(accountTypeIdentifier[0].equals("030")){
					System.out.println(accountNumber);
					//do nothing;
				}else if(accountTypeIdentifier[0].equals("020")||accountTypeIdentifier[0].equals("021")){
					accountNumber=accountTypeIdentifier[1];
					System.out.println(accountNumber);
				}
			}

			actualNotificationID = Utils.retrieveDetailsFromBazookaDB(query, "%"  + accountNumber + "%");
			Thread.sleep(4000);
			System.out.println("nottificationID++ " + actualNotificationID);

			emailNotificationEvent.setNotificationID(actualNotificationID);
			System.out.println("NificationId:"+emailNotificationEvent.getNotificationID());

			Utils.APP_LOGS.info("Exit: validateNotification()");

		} catch (Exception e) {
			Utils.APP_LOGS.error("Notification can not be validated" + e);
		}
		return actualNotificationID;

	}

}