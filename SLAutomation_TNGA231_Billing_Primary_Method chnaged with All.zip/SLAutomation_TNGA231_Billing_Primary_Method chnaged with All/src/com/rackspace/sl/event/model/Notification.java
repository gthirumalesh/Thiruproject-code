
package com.rackspace.sl.event.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class Notification.
 */
public class Notification {

    /** The notification id. */
    @SerializedName("notificationId")
    @Expose
    private String notificationId;
    
    /** The published date. */
    @SerializedName("publishedDate")
    @Expose
    private String publishedDate;
    
    /** The notification HTML. */
    @SerializedName("notificationHTML")
    @Expose
    private String notificationHTML;
    
    /** The parameters. */
    @SerializedName("parameters")
    @Expose
    private Parameters parameters;
    
    /** The attachments. */
    @SerializedName("attachments")
    @Expose
    private List<Object> attachments = null;
    
    /** The origin system. */
    @SerializedName("originSystem")
    @Expose
    private String originSystem;
    
    /** The sender. */
    @SerializedName("sender")
    @Expose
    private String sender;
    
    /** The recipients. */
    @SerializedName("recipients")
    @Expose
    private List<Recipient> recipients = null;

    /**
     * Gets the notification id.
     *
     * @return the notification id
     */
    public String getNotificationId() {
        return notificationId;
    }

    /**
     * Sets the notification id.
     *
     * @param notificationId the new notification id
     */
    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    /**
     * Gets the published date.
     *
     * @return the published date
     */
    public String getPublishedDate() {
        return publishedDate;
    }

    /**
     * Sets the published date.
     *
     * @param publishedDate the new published date
     */
    public void setPublishedDate(String publishedDate) {
        this.publishedDate = publishedDate;
    }

    /**
     * Gets the notification HTML.
     *
     * @return the notification HTML
     */
    public String getNotificationHTML() {
        return notificationHTML;
    }

    /**
     * Sets the notification HTML.
     *
     * @param notificationHTML the new notification HTML
     */
    public void setNotificationHTML(String notificationHTML) {
        this.notificationHTML = notificationHTML;
    }

    /**
     * Gets the parameters.
     *
     * @return the parameters
     */
    public Parameters getParameters() {
        return parameters;
    }

    /**
     * Sets the parameters.
     *
     * @param parameters the new parameters
     */
    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }

    /**
     * Gets the attachments.
     *
     * @return the attachments
     */
    public List<Object> getAttachments() {
        return attachments;
    }

    /**
     * Sets the attachments.
     *
     * @param attachments the new attachments
     */
    public void setAttachments(List<Object> attachments) {
        this.attachments = attachments;
    }

    /**
     * Gets the origin system.
     *
     * @return the origin system
     */
    public String getOriginSystem() {
        return originSystem;
    }

    /**
     * Sets the origin system.
     *
     * @param originSystem the new origin system
     */
    public void setOriginSystem(String originSystem) {
        this.originSystem = originSystem;
    }

    /**
     * Gets the sender.
     *
     * @return the sender
     */
    public String getSender() {
        return sender;
    }

    /**
     * Sets the sender.
     *
     * @param sender the new sender
     */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /**
     * Gets the recipients.
     *
     * @return the recipients
     */
    public List<Recipient> getRecipients() {
        return recipients;
    }

    /**
     * Sets the recipients.
     *
     * @param recipients the new recipients
     */
    public void setRecipients(List<Recipient> recipients) {
        this.recipients = recipients;
    }

}
