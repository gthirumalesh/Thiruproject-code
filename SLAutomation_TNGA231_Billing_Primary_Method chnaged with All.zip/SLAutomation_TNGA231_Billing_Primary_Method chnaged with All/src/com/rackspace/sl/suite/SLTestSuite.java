package com.rackspace.sl.suite;

import java.io.IOException;

import org.junit.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.rackspace.brm.account.constants.AccountConstants.AccountType;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.validation.AccountValidation;
import com.rackspace.sl.account.action.AccountAction;
import com.rackspace.sl.account.builder.AccountBuilder;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.action.EventAction;
import com.rackspace.sl.event.builder.EventBuilder;
import com.rackspace.sl.event.constants.EventConstants.EventType;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.rbacprofile.action.RBACProfileAction;
import com.rackspace.sl.rbacprofile.builder.RBACProfileBuilder;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants.RBACprofileType;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

/**
 * The Class SLTestSuite.
 */

public class SLTestSuite {

	/**
	 * Prepare report folder.
	 */
	@BeforeTest(alwaysRun = true)
	public void prepareReportFolder() {
		try {
			Utils.APP_LOGS.info("Enter: prepareReportFolder()");

			Utils.prepareTestDirectory();

			Utils.APP_LOGS.info("Exit: prepareReportFolder()");

		} catch (IOException e) {

			Utils.APP_LOGS.error("IOException in prepareReportFolder " + e);
		}
	}

	/**
	 * S L T S ACC T 01 validate create AQ notification for billing primary
	 * method changed.
	 *
	 * @param templateType
	 *            the template type
	 * @param profile
	 *            the profile
	 * @param currency
	 *            the currency
	 * @param payType
	 *            the pay type
	 * @param notificationOption
	 *            the notification option
	 * @param contractingEntity
	 *            the contracting entity
	 * @param invoiceDeliveryMethod
	 *            the invoice delivery method
	 * @param supportTeam
	 *            the support team
	 * @param paymentTerm
	 *            the pay term
	 * @param vatNumber
	 *            the vat number
	 * @param paymentType
	 *            the payment type
	 * @param inPvt
	 *            the in pvt
	 * @param polarity
	 *            the polarity
	 * @param testMethodName
	 *            the test method name
	 * @param suiteName
	 *            the suite name
	 * @param jsonFileName
	 *            the json file name
	 * @param xmlFileName
	 *            the xml file name
	 * @param xmlParentTagName
	 *            the xml parent tag name * @param In_AccountType the in
	 *            In_AccountType
	 */
	@Test(groups = { "Component", "Regression" })
	@Parameters({ "In_TemplateType", "In_Profile", "In_Currency", "In_Paytype", "In_NotificationOption",
			"In_ContractingEntity", "In_InvoiceDeliveryMethod", "In_SupportTeam", "In_PaymentTerm", "In_VatNumber",
			"In_PaymentType", "In_Pvt", "In_Polarity", "Out_Testname", "Out_Suitename", "Out_JsonFileName",
			"Out_XmlFileName", "Out_XmlParentTagName", "In_CardVerificationNumber", "In_CardHolderName",
			"In_CardNumber", "In_CardType", "In_ExpireDate", "In_AccountType" })

	/*
	 * Get Template Call from Bazooka.... Step2
	 */
	public void SL_TS_ACCT_01_SL_BILLING_PAYMENT_SUCCESS_CC(String templateType, String profile, String currency,
			String payType, String notificationOption, String contractingEntity, String invoiceDeliveryMethod,
			String supportTeam, String paymentTerm, String vatNumber, String paymentType, String inPvt, String polarity,
			String testMethodName, String suiteName, String jsonFileName, String xmlFileName, String xmlParentTagName,
			String cardVerificationNumber, String cardHolderName, String cardNumber, String cardType, String expireDate,
			AccountType accountType) {

		try {

			Utils.APP_LOGS.info("Starting SL_TS_ACCT_01_SL_BILLING_PAYMENT_SUCCESS_CCtestcase");

			// STEP 1: Generate Token
			RBACProfileBuilder rbacProfileBuilder = null;

			if (Utils.isNullOrEmpty(profile) || profile.equals(RBACprofileType.BSL_SYSTEM_ROLE.toString())) {
				rbacProfileBuilder = new RBACProfileBuilder(RBACprofileType.BSL_SYSTEM_ROLE);
			} else if (profile.equals(RBACprofileType.PROMOTION_AUTH.toString())) {
				rbacProfileBuilder = new RBACProfileBuilder(RBACprofileType.PROMOTION_AUTH);
			}

			RBACProfile ipRBACProfile = rbacProfileBuilder.getRBACProfile();
			// Create RBACprofileAction object
			RBACProfileAction rbacProfileAction = new RBACProfileAction();
			ipRBACProfile = rbacProfileAction.getToken(ipRBACProfile);
			Utils.APP_LOGS.info("TOKEN :" + ipRBACProfile.getToken());
			// Validate Token Generation
			Assert.assertNotNull(ipRBACProfile.getToken());

			String step1 = "Step 1: Token generated successfully for ";

			Utils.APP_LOGS.info(step1 + RBACprofileType.BSL_SYSTEM_ROLE);
			Utils.APP_LOGS.info(
					"The generated Token for " + RBACprofileType.BSL_SYSTEM_ROLE + " is " + ipRBACProfile.getToken());
			Reporter.log(step1 + RBACprofileType.BSL_SYSTEM_ROLE);

			// STEP 2: Validate the GET TEMPLATE call from BAZOOKA to fetch the
			// template for "PAYMENT_ADDED_ACH"
			EventBuilder eventGetTemplateByIDBuilder = new EventBuilder(EventType.GET_TEMPLATE_ID, templateType);
			Event emailTemplateByIDEvent = eventGetTemplateByIDBuilder.getEvent();
			String emailTemplateByIDEventas = emailTemplateByIDEvent.getTemplateType();
			System.out.println("%%%%% Template Type %%%%%%% " + emailTemplateByIDEventas);

			EventAction eventTemplateByIDAction = new EventAction();
			Assert.assertTrue(eventTemplateByIDAction.getTemplateById(emailTemplateByIDEvent, ipRBACProfile));

			String step2 = "Step 2: Validate the GET TEMPLATE call from BAZOOKA to fetch the template for PAYMENT_ADDED_ACH";

			Utils.APP_LOGS.info(step2);
			Reporter.log(step2);
			// STEP 3: Create a default dedicated account using BSL V2 "create
			// account" api

			AccountBuilder accountBuilder = new AccountBuilder(accountType, Utils.generateTenantId(),
					Utils.generateTenantId(), currency, payType, notificationOption, contractingEntity,
					invoiceDeliveryMethod, supportTeam, paymentTerm, vatNumber, paymentType, invoiceDeliveryMethod,
					notificationOption, Utils.getISO8601StringForCurrentDate(),
					String.valueOf(Utils.converToEpochTime(Utils.getPreviousMonthPvtDate(inPvt))), paymentType);
			/*
			 * Get accountNumber from BSL ...step4
			 */
			Account ipAccount = accountBuilder.getAccount();

			AccountAction accountAction = new AccountAction();

			/*
			 * CreateAccount DefaultDedicatedAccount ...step3
			 */
			Account opAccount = accountAction.createAccount(ipAccount, ipRBACProfile);

			/*
			 * Get Account call from BSL step4
			 */
			Utils.APP_LOGS.info("Accountno############" + opAccount.getAccountNumber());
			/*
			 * Validate Get AccountNumber from BSL
			 */
			Assert.assertFalse(Utils.isNullOrEmpty(opAccount.getAccountNumber()));
			/*
			 * AccountNumber Validation From FROm BSL step5
			 */
			Assert.assertEquals(200, accountAction.validateSLAccount(opAccount, ipRBACProfile));
			// Step 5 Call the "PCM_OP_PUBLISH_GEN_PAYLOAD" (opcode 1301)
			Account eventAccount = eventTemplateByIDAction.publishEvent(opAccount, emailTemplateByIDEvent);

			AccountValidation.ValidatePaymentMethod(eventAccount);

			String step5 = "Step 5: Call PCM_OP_PUBLISH_GEN_PAYLOAD (opcode 1301)";

			Utils.APP_LOGS.info(step5);
			Reporter.log(step5);

			// Step 6 Validate Notification Event NotificationEvent =
			String notificationID = eventTemplateByIDAction.getNotificationID(opAccount.getAccountNumber(),
					SLConstants.NOTIFICATION_QUERY);
			System.out.println("notificationID ==============  " + notificationID);
			String step6 = "Step 6: Validate Notification in Bazooka DB";

			Utils.APP_LOGS.info(step6);
			Reporter.log(step6);

		} catch (NullPointerException e) {
			Utils.APP_LOGS.error("Null pointer exception in SL_TS_ACCT_01_BILLING_PAYMENT_SUCCESS_CC " + e);
		} catch (Exception e) {
			Utils.APP_LOGS.error("Exception while executing SL_TS_ACCT_01_BILLING_PAYMENT_SUCCESS_CC " + e);
		}

	}

}
