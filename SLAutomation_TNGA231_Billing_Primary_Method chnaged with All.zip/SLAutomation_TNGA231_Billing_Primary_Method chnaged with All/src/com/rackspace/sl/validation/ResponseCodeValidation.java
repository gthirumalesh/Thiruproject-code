package com.rackspace.sl.validation;

import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;

import com.rackspace.brm.common.Utils;
import com.rackspace.brm.constants.BRMConstants;

import io.restassured.response.Response;

/**
 * The Class ResponseCodeValidation.
 */
public class ResponseCodeValidation {

	/**
	 * Validate response code 200.
	 *
	 * @param response the response
	 * @return true, if successful
	 */
	public static boolean validateResponseCode200(Response response) {

		boolean isSuccess = BRMConstants.isSuccessTrue;
		try {
			
			Utils.APP_LOGS.info("Enter: validateResponseCode200()");
			
			Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);
			
			Utils.APP_LOGS.info("Exit: validateResponseCode200()");

		} catch (RuntimeException e) {
			Utils.APP_LOGS.error("RuntimeException in validateResponseCode200 " + e);
			isSuccess = BRMConstants.isSuccessFalse;
		} catch (AssertionError e) {
			Utils.APP_LOGS.error("AssertionError in validateResponseCode200 " + e);
			//expected and actual are not matching
			isSuccess = BRMConstants.isSuccessFalse;
		}
		
		return isSuccess;

	}

	/**
	 * Validate response code 201.
	 *
	 * @param response the response
	 */
	public static void validateResponseCode201(Response response) {

		try {
			
			Utils.APP_LOGS.info("Enter: validateResponseCode201() ");

			Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED_201);
			
			Utils.APP_LOGS.info("Exit: validateResponseCode201() ");

		} catch (RuntimeException e) {
			Utils.APP_LOGS.error("RuntimeException in validateResponseCode201 " + e);
		}

	}

}
