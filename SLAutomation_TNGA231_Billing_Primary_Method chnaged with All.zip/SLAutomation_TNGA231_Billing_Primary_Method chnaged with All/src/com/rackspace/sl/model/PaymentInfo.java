
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class PaymentInfo.
 */
public class PaymentInfo {

    /** The payment type. */
    @SerializedName("paymentType")
    @Expose
    private String paymentType;
    
    /** The payment terms. */
    @SerializedName("paymentTerms")
    @Expose
    private String paymentTerms;
    
    /** The notification option. */
    @SerializedName("notificationOption")
    @Expose
    private String notificationOption;

    /**
     * Gets the payment type.
     *
     * @return the payment type
     */
    public String getPaymentType() {
        return paymentType;
    }

    /**
     * Sets the payment type.
     *
     * @param paymentType the new payment type
     */
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    /**
     * Gets the payment terms.
     *
     * @return the payment terms
     */
    public String getPaymentTerms() {
        return paymentTerms;
    }

    /**
     * Sets the payment terms.
     *
     * @param paymentTerms the new payment terms
     */
    public void setPaymentTerms(String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    /**
     * Gets the notification option.
     *
     * @return the notification option
     */
    public String getNotificationOption() {
        return notificationOption;
    }

    /**
     * Sets the notification option.
     *
     * @param notificationOption the new notification option
     */
    public void setNotificationOption(String notificationOption) {
        this.notificationOption = notificationOption;
    }

}
