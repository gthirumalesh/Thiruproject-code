
package com.rackspace.sl.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class BillingAccount.
 */
public class BillingAccount {

    /** The account number. */
    @SerializedName("accountNumber")
    @Expose
    private String accountNumber;
    
    /** The name. */
    @SerializedName("name")
    @Expose
    private String name;
    
    /** The service alias info. */
    @SerializedName("serviceAliasInfo")
    @Expose
    private ServiceAliasInfo serviceAliasInfo;
    
    /** The currency. */
    @SerializedName("currency")
    @Expose
    private String currency;
    
    /** The monthly recurring revenue. */
    @SerializedName("monthlyRecurringRevenue")
    @Expose
    private String monthlyRecurringRevenue;
    
    /** The contract entity. */
    @SerializedName("contractEntity")
    @Expose
    private String contractEntity;
    
    /** The org. */
    @SerializedName("org")
    @Expose
    private String org;
    
    /** The line of business. */
    @SerializedName("lineOfBusiness")
    @Expose
    private String lineOfBusiness;
    
    /** The signup date. */
    @SerializedName("signupDate")
    @Expose
    private String signupDate;
    
    /** The primary address. */
    @SerializedName("primaryAddress")
    @Expose
    private PrimaryAddress primaryAddress;
    
    /** The billing address. */
    @SerializedName("billingAddress")
    @Expose
    private BillingAddress billingAddress;
    
    /** The contact info. */
    @SerializedName("contactInfo")
    @Expose
    private ContactInfo contactInfo;
    
    /** The bill info. */
    @SerializedName("billInfo")
    @Expose
    private BillInfo billInfo;
    
    /** The payment info. */
    @SerializedName("paymentInfo")
    @Expose
    private PaymentInfo paymentInfo;
    
    /** The tax info. */
    @SerializedName("taxInfo")
    @Expose
    private TaxInfo taxInfo;
    
    /** The link. */
    @SerializedName("link")
    @Expose
    private List<Link> link = null;

    /**
     * Gets the account number.
     *
     * @return the account number
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the account number.
     *
     * @param accountNumber the new account number
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the service alias info.
     *
     * @return the service alias info
     */
    public ServiceAliasInfo getServiceAliasInfo() {
        return serviceAliasInfo;
    }

    /**
     * Sets the service alias info.
     *
     * @param serviceAliasInfo the new service alias info
     */
    public void setServiceAliasInfo(ServiceAliasInfo serviceAliasInfo) {
        this.serviceAliasInfo = serviceAliasInfo;
    }

    /**
     * Gets the currency.
     *
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the currency.
     *
     * @param currency the new currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Gets the monthly recurring revenue.
     *
     * @return the monthly recurring revenue
     */
    public String getMonthlyRecurringRevenue() {
        return monthlyRecurringRevenue;
    }

    /**
     * Sets the monthly recurring revenue.
     *
     * @param monthlyRecurringRevenue the new monthly recurring revenue
     */
    public void setMonthlyRecurringRevenue(String monthlyRecurringRevenue) {
        this.monthlyRecurringRevenue = monthlyRecurringRevenue;
    }

    /**
     * Gets the contract entity.
     *
     * @return the contract entity
     */
    public String getContractEntity() {
        return contractEntity;
    }

    /**
     * Sets the contract entity.
     *
     * @param contractEntity the new contract entity
     */
    public void setContractEntity(String contractEntity) {
        this.contractEntity = contractEntity;
    }

    /**
     * Gets the org.
     *
     * @return the org
     */
    public String getOrg() {
        return org;
    }

    /**
     * Sets the org.
     *
     * @param org the new org
     */
    public void setOrg(String org) {
        this.org = org;
    }

    /**
     * Gets the line of business.
     *
     * @return the line of business
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Sets the line of business.
     *
     * @param lineOfBusiness the new line of business
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * Gets the signup date.
     *
     * @return the signup date
     */
    public String getSignupDate() {
        return signupDate;
    }

    /**
     * Sets the signup date.
     *
     * @param signupDate the new signup date
     */
    public void setSignupDate(String signupDate) {
        this.signupDate = signupDate;
    }

    /**
     * Gets the primary address.
     *
     * @return the primary address
     */
    public PrimaryAddress getPrimaryAddress() {
        return primaryAddress;
    }

    /**
     * Sets the primary address.
     *
     * @param primaryAddress the new primary address
     */
    public void setPrimaryAddress(PrimaryAddress primaryAddress) {
        this.primaryAddress = primaryAddress;
    }

    /**
     * Gets the billing address.
     *
     * @return the billing address
     */
    public BillingAddress getBillingAddress() {
        return billingAddress;
    }

    /**
     * Sets the billing address.
     *
     * @param billingAddress the new billing address
     */
    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }

    /**
     * Gets the contact info.
     *
     * @return the contact info
     */
    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    /**
     * Sets the contact info.
     *
     * @param contactInfo the new contact info
     */
    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    /**
     * Gets the bill info.
     *
     * @return the bill info
     */
    public BillInfo getBillInfo() {
        return billInfo;
    }

    /**
     * Sets the bill info.
     *
     * @param billInfo the new bill info
     */
    public void setBillInfo(BillInfo billInfo) {
        this.billInfo = billInfo;
    }

    /**
     * Gets the payment info.
     *
     * @return the payment info
     */
    public PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }

    /**
     * Sets the payment info.
     *
     * @param paymentInfo the new payment info
     */
    public void setPaymentInfo(PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    /**
     * Gets the tax info.
     *
     * @return the tax info
     */
    public TaxInfo getTaxInfo() {
        return taxInfo;
    }

    /**
     * Sets the tax info.
     *
     * @param taxInfo the new tax info
     */
    public void setTaxInfo(TaxInfo taxInfo) {
        this.taxInfo = taxInfo;
    }

    /**
     * Gets the link.
     *
     * @return the link
     */
    public List<Link> getLink() {
        return link;
    }

    /**
     * Sets the link.
     *
     * @param link the new link
     */
    public void setLink(List<Link> link) {
        this.link = link;
    }

}
