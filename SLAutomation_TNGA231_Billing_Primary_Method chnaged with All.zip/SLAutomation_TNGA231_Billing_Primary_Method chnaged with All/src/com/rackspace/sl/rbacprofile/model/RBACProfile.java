package com.rackspace.sl.rbacprofile.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants.RBACprofileType;

/**
 * The Class RBACprofile.
 */
public class RBACProfile {

	/** The bsl username. */
	String bslUsername = null;

	/** The bsl password. */
	String bslPassword = null;

	/** The token. */
	String token = null;

	/** The accountType reference of the AccountType class. */
	RBACprofileType rbacProfileType = null;

	/**
	 * Gets the rbac profile type.
	 *
	 * @return the rbac profile type
	 */
	public RBACprofileType getRbacProfileType() {
		return rbacProfileType;
	}

	/**
	 * Sets the rbac profile type.
	 *
	 * @param rbacProfileType
	 *            the new rbac profile type
	 */
	public void setRbacProfileType(RBACprofileType rbacProfileType) {
		this.rbacProfileType = rbacProfileType;
	}

	/**
	 * Gets the bsl username.
	 *
	 * @return the bsl username
	 */
	public String getBslUsername() {
		return bslUsername;
	}

	/**
	 * Sets the bsl username.
	 *
	 * @param bslUsername
	 *            the new bsl username
	 */
	public void setBslUsername(String bslUsername) {
		this.bslUsername = bslUsername;
	}

	/**
	 * Gets the bsl password.
	 *
	 * @return the bsl password
	 */
	public String getBslPassword() {
		return bslPassword;
	}

	/**
	 * Sets the bsl password.
	 *
	 * @param bslPassword
	 *            the new bsl password
	 */
	public void setBslPassword(String bslPassword) {
		this.bslPassword = bslPassword;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Sets the token.
	 *
	 * @param token
	 *            the new token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	
	/** The access. */
    @SerializedName("access")
    @Expose
    private Access access;

    /**
     * Gets the access.
     *
     * @return the access
     */
    public Access getAccess() {
        return access;
    }

    /**
     * Sets the access.
     *
     * @param access the new access
     */
    public void setAccess(Access access) {
        this.access = access;
    }

	
	
}
