package com.rackspace.brm.connection;

import com.portal.pcm.EBufException;
import com.portal.pcm.PortalContext;
import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.PropertyUtil;

public class BRMPortalConnection extends BaseConnection {

	private static boolean isInitialized = false;
	public static PortalContext portalContext = null;

	public BRMPortalConnection() {
	}

	public static synchronized PortalContext getBRMPortalConnection() throws EBufException {

		if (!isInitialized) {
			portalContext = new PortalContext();
			portalContext.connect(PropertyUtil.getInfranetProperties());
			isInitialized = true;
		}

		return portalContext;
	}

}
