package com.rackspace.brm.constants;

public final class BillConstants {

	/**
	 * This section to hold all opcode names
	 */

	public static final String HIEARCHICAL_CHILD_ACCOUNT_BILLQUERY = "childHierarchicalBillQuery";

}
