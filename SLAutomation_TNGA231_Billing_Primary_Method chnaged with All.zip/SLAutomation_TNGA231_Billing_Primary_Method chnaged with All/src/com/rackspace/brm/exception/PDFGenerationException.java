package com.rackspace.brm.exception;

/**
 * PDFGenerationException is a custom exception will throw exception while doing
 * PDF Generation.
 * 
 */
public class PDFGenerationException extends Exception {

	/**
	 * The Constant serialVersionUID. The serialVersionUID is used as a version
	 * control in a Serializable class. If you do not explicitly declare a
	 * serialVersionUID, JVM will do it for you automatically, based on various
	 * aspects of your Serializable class
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of PDFGenerationException, exception class here copying the
	 * message and cause that we are passing while throwing the exception to a
	 * string and then displaying that string along with the message.
	 * 
	 * @param message
	 *            display the message which passing
	 * @param cause
	 *            display the cause
	 */
	public PDFGenerationException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * Constructor of PDFGenerationException, exception class here copying the
	 * message that we are passing while throwing the exception to a string and
	 * then displaying that string along with the message.
	 * 
	 * @param message
	 *            display the message which passing
	 */
	public PDFGenerationException(String message) {
		super(message);

	}

	/**
	 * Constructor of PDFGenerationException, exception class here copying the
	 * cause that we are passing while throwing the exception
	 * 
	 * @param obj
	 *            display the reason
	 */
	public PDFGenerationException(Throwable cause) {
		super(cause);

	}

}
