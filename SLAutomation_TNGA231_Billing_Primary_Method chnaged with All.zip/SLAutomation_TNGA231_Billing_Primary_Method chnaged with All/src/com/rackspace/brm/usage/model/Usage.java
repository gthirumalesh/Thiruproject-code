package com.rackspace.brm.usage.model;

import com.rackspace.brm.usage.constants.UsageConstants.DedicatedUsageLinesType;
import com.rackspace.brm.usage.constants.UsageConstants.UsageType;

// TODO: Auto-generated Javadoc
/**
 * The Class Usage.
 */
public abstract class Usage {

	/** The usage type. */
	UsageType usageType = null;
	
	/** The dedicated usage lines type. */
	DedicatedUsageLinesType dedicatedUsageLinesType = null;

	/** The batch id. */
	protected String batchId = null;
	
	/** The from date. */
	protected String fromDate = null;
	
	/** The end date. */
	protected String endDate = null;

	/**
	 * Instantiates a new usage.
	 *
	 * @param usageType the usage type
	 */
	public Usage(UsageType usageType) {

		this.usageType = usageType;
	}

	/**
	 * Gets the usage type.
	 *
	 * @return the usage type
	 */
	public UsageType getUsageType() {
		return usageType;
	}

	/**
	 * Sets the usage type.
	 *
	 * @param usageType the new usage type
	 */
	public void setUsageType(UsageType usageType) {
		this.usageType = usageType;
	}

	
	/**
	 * Gets the dedicated usage lines type.
	 *
	 * @return the dedicated usage lines type
	 */
	public DedicatedUsageLinesType getDedicatedUsageLinesType() {
		return dedicatedUsageLinesType;
	}

	/**
	 * Sets the dedicated usage lines type.
	 *
	 * @param dedicatedUsageLinesType the new dedicated usage lines type
	 */
	public void setDedicatedUsageLinesType(DedicatedUsageLinesType dedicatedUsageLinesType) {
		this.dedicatedUsageLinesType = dedicatedUsageLinesType;
	}

	/**
	 * Gets the batch id.
	 *
	 * @return the batch id
	 */
	public String getBatchId() {
		return batchId;
	}

	/**
	 * Sets the batch id.
	 *
	 * @param batchId the new batch id
	 */
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	/**
	 * Gets the from date.
	 *
	 * @return the from date
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Sets the from date.
	 *
	 * @param fromDate the new from date
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate the new end date
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	

}
