package com.rackspace.brm.purchaseorder.action;

import java.io.File;
import java.io.IOException;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.purchaseorder.constants.PurchaseOrderType;
import com.rackspace.brm.purchaseorder.dao.DedicatedPurchaseOrderDAO;
import com.rackspace.brm.purchaseorder.model.DedicatedPurchaseOrder;
import com.rackspace.brm.purchaseorder.model.PurchaseOrder;

/**
 * The Class PurchaseOrderAction.
 */
public class PurchaseOrderAction {

	/** The purchaseOrder reference of the PurchaseOrder class */
	PurchaseOrder purchaseOrder = null;

	/**
	 * Instantiates a new purchase order action.
	 */
	public PurchaseOrderAction() {
	}

	/**
	 * Instantiates a new purchase order action.
	 *
	 * @param purchaseOrderType
	 *            used store the purchase order type
	 * @param accountNumber
	 *            used to store the account number
	 * @param tenantId
	 *            used to store the tenant Id
	 * @param pvt
	 *            used to store the PVT
	 */
	public PurchaseOrderAction(PurchaseOrderType purchaseOrderType, String accountNumber, String tenantId, String pvt) {

		purchaseOrder = PurchaseOrderFactory.createPurchaseOrder(purchaseOrderType);
		purchaseOrder.setAccountNumber(accountNumber);
		purchaseOrder.setTenantID(tenantId);
		purchaseOrder.setEffectiveDate(pvt);

	}

	/**
	 * Creates the purchase order.
	 *
	 * @return the purchaseOrder number
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 * 
	 */
	public PurchaseOrder createPurchaseOrder() throws IOException, EBufException {

		switch (purchaseOrder.getPurchaseOrderType()) {

		case DEDICATED:

			DedicatedPurchaseOrder dedicatedPurchaseOrder = (DedicatedPurchaseOrder) (purchaseOrder);
			String flistData = BRMUtils.buildInputPOFlist(dedicatedPurchaseOrder);
			DedicatedPurchaseOrderDAO dedicatedPurchaseOrderDAO = new DedicatedPurchaseOrderDAO();
			FList outFlist = dedicatedPurchaseOrderDAO.createPurchaseOrder(flistData);
			String outputFlistString = outFlist.asString();

			File outfile = Utils.createFilePo(outputFlistString, "Flist_0_RAX_OP_CUST_COMMIT_CUSTOMER.out");
			String purchaseOrderNumber = Utils.readOutputFile(outfile, "PIN_FLD_PO_ORDER_NO", "[0]");

			purchaseOrder.setPurchaseOrderNumber(purchaseOrderNumber);

		case CLOUD:

			break;
		default:
			// logic for expecting if the case is end to switch case
			break;
		}
		return purchaseOrder;

	}
}
