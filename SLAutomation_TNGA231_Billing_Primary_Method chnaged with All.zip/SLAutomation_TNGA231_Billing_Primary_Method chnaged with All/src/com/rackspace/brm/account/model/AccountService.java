package com.rackspace.brm.account.model;

public class AccountService {
	String serviceObj = null;
	String login = null;
	long effectiveT = 0l;

	public String getServiceObj() {
		return serviceObj;
	}

	public void setServiceObj(String serviceObj) {
		this.serviceObj = serviceObj;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public long getEffectiveT() {
		return effectiveT;
	}

	public void setEffectiveT(long effectiveT) {
		this.effectiveT = effectiveT;
	}

}
