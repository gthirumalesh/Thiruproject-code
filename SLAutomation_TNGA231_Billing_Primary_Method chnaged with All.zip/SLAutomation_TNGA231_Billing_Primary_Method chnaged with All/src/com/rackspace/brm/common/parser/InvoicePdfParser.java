package com.rackspace.brm.common.parser;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.parser.PdfTextExtractor;
import com.rackspace.brm.account.model.AccountInvoice;
import com.rackspace.brm.common.Utils;

public class InvoicePdfParser {

	public static final String PATTERN_ACCT_NUMBER = "(.*?)\\s*Account\\s*Number\\s*:\\s*(\\d+-\\d+)\\s*";
	public static final String PATTERN_CUST_ACCT_NUMBER = "(.*?)\\s*Customer\\s*Number\\s*:\\s*(\\d+)\\s*";
	public static final String PATTERN_INVOICE_NUMBER = "(.*?)\\s*Invoice\\s*Number\\s*:\\s*([A-Z1-9]+-\\d+)\\s*";
	public static final String PATTERN_INVOICE_DATE = "(.*?)\\s*Invoice\\s*Date\\s*:\\s*([A-Z1-9-a-z]+)\\s*";
	public static final String PATTERN_CURRENCY = "(.*?)\\s*Currency\\s*:\\s*\\(([$])+\\)\\s*";
	public static final String PATTERN_AMOUNT_DUE = ".*?\\s*Invoice\\s*Amount\\s*Due\\s*:\\s*([$])\\s*([0-9.,]+)(.*?)";

	AccountInvoice accountInvoice = null;
	PdfReader reader = null;
	PdfTextExtractor extractor = null;

	public AccountInvoice parseInvoicePDF(String invoiceFilePath) {

		try {
			accountInvoice = new AccountInvoice();
			reader = new PdfReader(invoiceFilePath);
			extractor = new PdfTextExtractor(reader);

			this.parseAccountInformation(1);

		} catch (Exception ex) {

		} finally {
			// Release all the resources
		}
		return accountInvoice;
	}

	private void parseAccountInformation(int pageNumber) {

		Utils.APP_LOGS.info("Entry:  getAccountNumberFromPdfFile()");
		try {
			// Reader to read the pdf
			String line = extractor.getTextFromPage(pageNumber);
			accountInvoice.setAccountNumber(this.getValue(line, PATTERN_ACCT_NUMBER, "Account Number"));
			accountInvoice.setCustomerNumber(this.getValue(line, PATTERN_CUST_ACCT_NUMBER, "Customer Number"));
			accountInvoice.setInvoiceNumber(this.getValue(line, PATTERN_INVOICE_NUMBER, "Invoice Number"));
			accountInvoice.setInvoiceDate(this.getValue(line, PATTERN_INVOICE_DATE, "Invoice Date"));
			accountInvoice.setCurrency(this.getValue(line, PATTERN_CURRENCY, "Currency"));
			accountInvoice.setInvoiceAmountDue(this.getValue(line, PATTERN_AMOUNT_DUE, "Invoice Amount Due"));

			Utils.APP_LOGS.info("Exit:  getAccountNumberFromPdfFile()");

		} catch (Exception e) {

		}
	}

	private String getValue(String line, String pattern, String fieldName) {
		String value = null;
		Pattern r = Pattern.compile(pattern);
		if (line.contains(fieldName)) {
			Matcher m = r.matcher(line);
			if (m.find()) {
				value = m.group(2);
			}
		}
		return value;
	}
}
