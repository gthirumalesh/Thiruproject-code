package com.rackspace.brm.account.model;

/**
 * The Class AccountProfile.
 */
public class AccountProfile {

	/**
	 * The spendLimitThreshold represents the spend Limit Threshold variable
	 */
	protected String spendLimitThreshold = null;

	/**
	 * The accountStatus represents the account status variable
	 */
	protected String accountStatus = null;

	/**
	 * The approvalDeniedStatus represents the approval denied status variable
	 */
	protected String approvalDeniedStatus = null;

	/**
	 * The contractingEntity represents the contracting entity variable
	 */
	protected String contractingEntity = null;

	/**
	 * The coreAcctNo represents the core account number variable
	 */
	protected String coreAccountNumber = null;

	/**
	 * The emailInvOptinFlag represents the email invoice OptIn flag variable
	 */
	protected String emailInvoiceOptinFlag = null;

	/**
	 * The invoiceAonsolidationAccount represents the invoice invoice
	 * Consolidation Account variable
	 */
	protected String invoiceConsolidationAccount = null;

	/**
	 * The invoicConsolidationFlag represents the invoice invoice Consolidation
	 * flag variable
	 */
	protected String invoiceConsolidationFlag = null;

	/**
	 * The manualAllocate represents the invoice manual allocate variable
	 */
	protected String manualAllocate = null;

	/**
	 * The optinFlag represents the optIn flag variable
	 */
	protected String optinFlag = null;

	/**
	 * The organization represents the organization variable
	 */
	protected String organization = null;

	/**
	 * The primaryAddressValid represents the primary address valid variable
	 */
	protected String primaryAddressValid = null;

	/**
	 * The supporTeam represents the support team variable
	 */
	protected String supportTeam = null;

	/**
	 * The thresholdNotifOptinFlag represents the threshold Notification Optin
	 * Flag variable
	 */
	protected String thresholdNotificationOptinFlag = null;

	/**
	 * The tpcEffectiveDate represents the TPC Effective Date variable
	 */
	protected String tpcEffectiveDate = null;

	/**
	 * The tpcFlag represents the TPC Flag variable
	 */
	protected String tpcFlag = null;

	/**
	 * The tpcOverdueAmount represents the TPC Overdue Amount variable
	 */
	protected String tpcOverdueAmount = null;

	/**
	 * The vatNumber represents the vatNumber variable
	 */
	protected String vatNumber = null;

	/**
	 * The virtualStatus represents the virtual status variable
	 */
	protected String virtualStatus = null;

	protected String paymentTerm = null;

	protected String paperlessMemoFlag = null;
	protected String paperlessInvoiceFlag = null;

	public AccountProfile() {

	}

	public void setCoreAccountNumber(String coreAccountNumber) {
		this.coreAccountNumber = coreAccountNumber;
	}

	/**
	 * Gets the spend limit threshold
	 *
	 * @return the spend limit threshold
	 */
	public String getSpendLimitThreshold() {
		return spendLimitThreshold;
	}

	/**
	 * Sets the spend limit threshold
	 *
	 * @param spendLimitThreshold
	 *            used to set the new spend limit threshold
	 */
	public void setSpendLimitThreshold(String spendLimitThreshold) {
		this.spendLimitThreshold = spendLimitThreshold;
	}

	/**
	 * Gets the account status.
	 *
	 * @return the account status
	 */
	public String getAccountStatus() {
		return accountStatus;
	}

	/**
	 * Sets the account status.
	 *
	 * @param accountStatus
	 *            used to set the new account status
	 */
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	/**
	 * Gets the approval denied status.
	 *
	 * @return the approval denied status
	 */
	public String getApprovalDeniedStatus() {
		return approvalDeniedStatus;
	}

	/**
	 * Sets the approval denied status.
	 *
	 * @param approvalDeniedStatus
	 *            used to set the new approval denied status
	 */
	public void setApprovalDeniedStatus(String approvalDeniedStatus) {
		this.approvalDeniedStatus = approvalDeniedStatus;
	}

	/**
	 * Gets the contracting entity.
	 *
	 * @return the contracting entity
	 */
	public String getContractingEntity() {
		return contractingEntity;
	}

	/**
	 * Sets the contracting entity.
	 *
	 * @param contractingEntity
	 *            used to set the new contracting entity
	 */
	public void setContractingEntity(String contractingEntity) {
		this.contractingEntity = contractingEntity;
	}

	/**
	 * Gets the core accountNumber.
	 *
	 * @return the core accountNumber
	 */
	public String getCoreAccountNumber() {
		return coreAccountNumber;
	}

	/**
	 * Gets the email invoice optin flag.
	 *
	 * @return the email invoice optin flag
	 */
	public String getEmailInvoiceOptinFlag() {
		return emailInvoiceOptinFlag;
	}

	/**
	 * Sets the email invoice optin flag.
	 *
	 * @param emailInvOptinFlag
	 *            used to set the new email invoice optin flag
	 */
	public void setEmailInvoiceOptinFlag(String emailInvoiceOptinFlag) {
		this.emailInvoiceOptinFlag = emailInvoiceOptinFlag;
	}

	/**
	 * Gets the invoice consolidation account.
	 *
	 * @return the invoice consolidation account
	 */
	public String getInvoiceConsolidationAccount() {
		return invoiceConsolidationAccount;
	}

	/**
	 * Sets the invoice consolidation account.
	 *
	 * @param invoiceConsolidationAccount
	 *            used to set the new invoice consolidation account
	 */
	public void setInvoiceConsolidationAccount(String invoiceConsolidationAccount) {
		this.invoiceConsolidationAccount = invoiceConsolidationAccount;
	}

	/**
	 * Gets the invoice consolidation flag.
	 *
	 * @return the invoice consolidation flag
	 */
	public String getInvoiceConsolidationFlag() {
		return invoiceConsolidationFlag;
	}

	/**
	 * Sets the invoice consolidation flag.
	 *
	 * @param invoiceConsolidationFlag
	 *            used to set the new invoice consolidation flag
	 */
	public void setInvoiceConsolidationFlag(String invoiceConsolidationFlag) {
		this.invoiceConsolidationFlag = invoiceConsolidationFlag;
	}

	/**
	 * Gets the manual allocate.
	 *
	 * @return the manual allocate
	 */
	public String getManualAllocate() {
		return manualAllocate;
	}

	/**
	 * Sets the manual allocate.
	 *
	 * @param manualAllocate
	 *            used to set the new manual allocate
	 */
	public void setManualAllocate(String manualAllocate) {
		this.manualAllocate = manualAllocate;
	}

	/**
	 * Gets the optin flag.
	 *
	 * @return the optIn flag
	 */
	public String getOptinFlag() {
		return optinFlag;
	}

	/**
	 * Sets the optinFlag.
	 *
	 * @param optinFlag
	 *            used to set the new optin flag
	 */
	public void setOptinFlag(String optinFlag) {
		this.optinFlag = optinFlag;
	}

	/**
	 * Gets the organization.
	 *
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 * Sets the organization.
	 *
	 * @param organization
	 *            used to set the new organization
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	/**
	 * Gets the primary address valid.
	 *
	 * @return the primary address valid
	 */
	public String getPrimaryAddressValid() {
		return primaryAddressValid;
	}

	/**
	 * Sets the primary address valid.
	 *
	 * @param primaryAddrValid
	 *            used to set the new primary address valid
	 */
	public void setPrimaryAddressValid(String primaryAddressValid) {
		this.primaryAddressValid = primaryAddressValid;
	}

	/**
	 * Gets the support team.
	 *
	 * @return the support team
	 */
	public String getSupportTeam() {
		return supportTeam;
	}

	/**
	 * Sets the support team.
	 *
	 * @param supportTeam
	 *            used to set the new support team
	 */
	public void setSupportTeam(String supportTeam) {
		this.supportTeam = supportTeam;
	}

	/**
	 * Gets the threshold notification optin flag.
	 *
	 * @return the threshold notification optin flag
	 */
	public String getThresholdNotificationOptinFlag() {
		return thresholdNotificationOptinFlag;
	}

	/**
	 * Sets the threshold notification optin flag.
	 *
	 * @param thresholdNotificationOptinFlag
	 *            used to set the new threshold notification optin flag
	 */
	public void setThresholdNotificationOptinFlag(String thresholdNotificationOptinFlag) {
		this.thresholdNotificationOptinFlag = thresholdNotificationOptinFlag;
	}

	/**
	 * Gets the TPC effective date.
	 *
	 * @return the TPC effective date
	 */
	public String getTpcEffectiveDate() {
		return tpcEffectiveDate;
	}

	/**
	 * Sets the TPC effective date.
	 *
	 * @param tpcEffectiveDate
	 *            used to set the new TPC effective date
	 */
	public void setTpcEffectiveDate(String tpcEffectiveDate) {
		this.tpcEffectiveDate = tpcEffectiveDate;
	}

	/**
	 * Gets the TPC flag.
	 *
	 * @return the TPC flag
	 */
	public String getTpcFlag() {
		return tpcFlag;
	}

	/**
	 * Sets the TPC flag.
	 *
	 * @param tpcFlag
	 *            used to set the new TPC flag
	 */
	public void setTpcFlag(String tpcFlag) {
		this.tpcFlag = tpcFlag;
	}

	/**
	 * Gets the TPC overdue amount.
	 *
	 * @return the TPC overdue amount
	 */
	public String getTpcOverdueAmt() {
		return tpcOverdueAmount;
	}

	/**
	 * Sets the TPC overdue amount.
	 *
	 * @param tpcOverdueAmount
	 *            used to set the new TPC overdue amount
	 */
	public void setTpcOverdueAmountt(String tpcOverdueAmount) {
		this.tpcOverdueAmount = tpcOverdueAmount;
	}

	/**
	 * Gets the vat number.
	 *
	 * @return the vat number
	 */
	public String getVatNumber() {
		return vatNumber;
	}

	/**
	 * Sets the vat number.
	 *
	 * @param vatNumber
	 *            used to set the new vat number
	 */
	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}

	/**
	 * Gets the virtual status.
	 *
	 * @return the virtual status
	 */
	public String getVirtualStatus() {
		return virtualStatus;
	}

	/**
	 * Sets the virtual status.
	 *
	 * @param virtualStatus
	 *            used to set the new virtual status
	 */
	public void setVirtualStatus(String virtualStatus) {
		this.virtualStatus = virtualStatus;
	}

	public String getTpcOverdueAmount() {
		return tpcOverdueAmount;
	}

	public void setTpcOverdueAmount(String tpcOverdueAmount) {
		this.tpcOverdueAmount = tpcOverdueAmount;
	}

	public String getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(String paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public String getPaperlessMemoFlag() {
		return paperlessMemoFlag;
	}

	public void setPaperlessMemoFlag(String paperlessMemoFlag) {
		this.paperlessMemoFlag = paperlessMemoFlag;
	}

	public String getPaperlessInvoiceFlag() {
		return paperlessInvoiceFlag;
	}

	public void setPaperlessInvoiceFlag(String paperlessInvoiceFlag) {
		this.paperlessInvoiceFlag = paperlessInvoiceFlag;
	}

}
