package com.rackspace.brm.account.model;

import java.util.ArrayList;

import com.rackspace.brm.account.constants.AccountConstants.AccountType;

/**
 * The Class Account.
 */
public class Account {

	/**  The BRM account object ID. */
	String accountObj = null;

	/** The account number. */
	String accountNumber = null;

	/** The tenant id. */
	String tenantId = null;
	/** The glSegment represents the GL Segment variable. */
	String glSegment = null;

	/** The currency represents the currency variable. */
	String currency = null;

	/** The start date. */
	String startDate = null;
	
	/**  The end date. */
	String endDate = null;

	/** The effective date represents the Effective Date of an account which is being created. */
	long effectiveDate = 0l;

	/** The accountType reference of the AccountType class. */
	AccountType accountType = null;

	/**  The account profile object. */
	AccountProfile accountProfile = null;
	
	/**  The account bill info object. */
	ArrayList<AccountBillInfo> accBillInfoList = new ArrayList<AccountBillInfo>();

	/** The bill list. */
	ArrayList<AccountBill> billList = new ArrayList<AccountBill>();;

	/** The account name info list. */
	ArrayList<AccountNameInfo> accountNameInfoList = new ArrayList<AccountNameInfo>();;

	/** The payinfo list. */
	ArrayList<AccountPayInfo> payinfoList = new ArrayList<AccountPayInfo>();;

	/**
	 * Gets the acc bill info list.
	 *
	 * @return the acc bill info list
	 */
	public ArrayList<AccountBillInfo> getAccBillInfoList() {
		return accBillInfoList;
	}

	/**
	 * Sets the acc bill info list.
	 *
	 * @param accBillInfoList the new acc bill info list
	 */
	public void setAccBillInfoList(ArrayList<AccountBillInfo> accBillInfoList) {
		this.accBillInfoList = accBillInfoList;
	}

	/**
	 * Gets the account name info list.
	 *
	 * @return the account name info list
	 */
	public ArrayList<AccountNameInfo> getAccountNameInfoList() {
		return accountNameInfoList;
	}

	/**
	 * Sets the acc bill info.
	 *
	 * @param accountNameInfoList the new acc bill info
	 */
	public void setAccBillInfo(ArrayList<AccountNameInfo> accountNameInfoList) {
		this.accountNameInfoList = accountNameInfoList;
	}

	/**
	 * Gets the acc profile.
	 *
	 * @return the acc profile
	 */
	public AccountProfile getAccountProfile() {
		return accountProfile;
	}

	/**
	 * Sets the acc profile.
	 *
	 * @param accountProfile the new account profile
	 */
	public void setAccountProfile(AccountProfile accountProfile) {
		this.accountProfile = accountProfile;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate
	 *            the new effective date
	 */
	public void setEffectiveDate(long effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Instantiates a new account.
	 * 
	 * @param accountType
	 *            used for the account type like DEDICATED or CLOUD
	 */
	public Account(AccountType accountType) {
		this.accountType = accountType;
	}

	/**
	 * Gets the GL segment.
	 *
	 * @return the GL segment
	 */
	public AccountType getAccountType() {
		return accountType;
	}

	/**
	 * Sets the account type.
	 *
	 * @param accountType
	 *            used to set the new account type
	 */
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	/**
	 * Sets the billing segment.
	 *
	 * @return the gl segment
	 */
	public String getGlSegment() {
		return glSegment;
	}

	/**
	 * Sets the GL segment.
	 *
	 * @param glSegment
	 *            used to set the new GL segment
	 */
	public void setGlSegment(String glSegment) {
		this.glSegment = glSegment;
	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effective date
	 */
	public long getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate
	 *            used to set the new effective date
	 */
	public void setEffective_date(long effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Gets the currency.
	 *
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Sets the currency.
	 *
	 * @param currency
	 *            used to set the new currency
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Gets the start date.
	 *
	 * @return the start date
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * Sets the start date.
	 *
	 * @param startDate
	 *            the new start date
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * Gets the end date.
	 *
	 * @return the end date
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * Sets the end date.
	 *
	 * @param endDate
	 *            the new end date
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the account obj.
	 *
	 * @return the account obj
	 */
	public String getAccountObj() {
		return accountObj;
	}

	/**
	 * Sets the account obj.
	 *
	 * @param accountObj the new account obj
	 */
	public void setAccountObj(String accountObj) {
		this.accountObj = accountObj;
	}

	/**
	 * Sets the account name info list.
	 *
	 * @param accountNameInfoList the new account name info list
	 */
	public void setAccountNameInfoList(ArrayList<AccountNameInfo> accountNameInfoList) {
		this.accountNameInfoList = accountNameInfoList;
	}

	/**
	 * Gets the bill list.
	 *
	 * @return the bill list
	 */
	public ArrayList<AccountBill> getBillList() {
		return billList;
	}

	/**
	 * Sets the bill list.
	 *
	 * @param billList the new bill list
	 */
	public void setBillList(ArrayList<AccountBill> billList) {
		this.billList = billList;
	}

	/**
	 * Gets the payinfo list.
	 *
	 * @return the payinfo list
	 */
	public ArrayList<AccountPayInfo> getPayinfoList() {
		return payinfoList;
	}

	/**
	 * Sets the payinfo list.
	 *
	 * @param payinfoList the new payinfo list
	 */
	public void setPayinfoList(ArrayList<AccountPayInfo> payinfoList) {
		this.payinfoList = payinfoList;
	}

	/**
	 * Gets the tenant id.
	 *
	 * @return the tenant id
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * Sets the tenant id.
	 *
	 * @param tenantId the new tenant id
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * Instantiates a new account.
	 */
	public Account() {

	}
}