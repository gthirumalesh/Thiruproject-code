package com.rackspace.brm.connection;

import java.sql.Connection;
import java.sql.DriverManager;

import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;

public class BazookaDBConnection extends BaseConnection {

	public static Connection connection = null;
	private static volatile boolean isInitialized = false;

	protected BazookaDBConnection() {
	}


	
	public static synchronized Connection getBazookaDBConnection() throws Exception {

		if (!isInitialized) {

			String sDBHost = PropertyUtil.getCommonProperties().getProperty("bazookaDBHost");
			String sDBUser = PropertyUtil.getCommonProperties().getProperty("bazookaDBUser");
			String sDBPwd = PropertyUtil.getCommonProperties().getProperty("bazookaDBPwd");
			String sDBSid = PropertyUtil.getCommonProperties().getProperty("bazookaDBSid");
			String port = PropertyUtil.getCommonProperties().getProperty("bazookaport");

			// load the driver class
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// create the connection object
			/*connection = DriverManager.getConnection("jdbc:oracle:thin:@" + sDBHost + ":" + port + ":" + sDBSid,
					sDBUser, sDBPwd);*/
			
		/*	connection = DriverManager.getConnection("jdbc:oracle:thin:@//" + sDBHost + ":" + port + "/" + sDBSid,
					sDBUser, sDBPwd);*/
			
			connection = DriverManager.getConnection("jdbc:oracle:thin:"+sDBUser+"/"+sDBPwd+"@//"+sDBHost+":"+port+"/"+sDBSid);
			
			//jdbc:oracle:thin:@//HOSTNAME:PORT/SERVICENAME

			Utils.APP_LOGS.info("BRM DB Connection is established"+ connection);
			isInitialized = true;
		}
		return connection;
	}

}

