package com.rackspace.brm.common.validation;

import java.lang.reflect.Method;
import java.util.ArrayList;

import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.account.model.AccountBillInfo;
import com.rackspace.brm.account.model.AccountProfile;

public class AttributeValidator {

	public static AttributeValidator attributeValidator = null;

	private AttributeValidator() {

	}

	public static AttributeValidator getAttributeValidator() {
		if (attributeValidator == null) {
			attributeValidator = new AttributeValidator();
		}
		return attributeValidator;
	}

	public boolean validateAttributes(String acctParameterList, Object inputObject, Object outputObject)
			throws Exception {
		String[] parameters = acctParameterList.split(",");
		boolean isAllValid = true;
		for (int i = 0; i < parameters.length; i++) {
			
			String expectedValue = this.getAttributeValue(inputObject, parameters[i]);
			String outputValue = this.getAttributeValue(outputObject, parameters[i]);

			if (expectedValue.equals(outputValue)) {
				System.out.println(inputObject.getClass().getSimpleName() + "." + parameters[i]
						+ "  Attribute Validation Success.");
			} else {
				System.out.println(inputObject.getClass().getSimpleName() + "." + parameters[i]
						+ "  Attribute Validation Failed." + " Comparison:expectedValue .vs. outputValue:"
						+ expectedValue + " .vs. " + outputValue);
				isAllValid = false;
				break;
			}
		}
		return isAllValid;
	}

	/**
	 * Gets value from object using reflection.
	 * 
	 * @param object
	 *            the object
	 * @param fieldName
	 *            the field
	 * @return the value
	 * @throws Exception
	 */
	public String getAttributeValue(Object object, String fieldName) throws Exception {

		// get class
		Class<? extends Object> cls = object != null ? object.getClass() : null;
		if (cls == null) {
			return null;
		}

		// get object value using reflection
		String getterName = "get" + fieldName;
		try {
			Method method = cls.getMethod(getterName);
			Object valueObject = method.invoke(object, (Object[]) null);
			return valueObject != null ? valueObject.toString() : "";
		} catch (Exception e) {
			// ignore all reflection errors
			throw e;
		}
	}
	
	public static void main(String[] args) throws Exception {
		String acctParameters = "Currency";
		String acctBillInfoPara = "ActgFutureDom";
		String acctProfileCoreAcct = "CoreAccountNumber";
		
		Account ipAccount = new Account();
		ipAccount.setCurrency("840");
		AccountBillInfo billinfo = new AccountBillInfo();
		ArrayList<AccountBillInfo> billInfoList = new ArrayList<AccountBillInfo>();
		billInfoList.add(billinfo);
		ipAccount.setAccBillInfoList(billInfoList);
		ipAccount.getAccBillInfoList().get(0).setActgFutureDom("04");
		AccountProfile profile = new AccountProfile();
		ipAccount.setAccountProfile(profile);
		ipAccount.getAccountProfile().setCoreAccountNumber("CORE-1234");
		
		Account opAccount = new Account();
		opAccount.setCurrency("840");
		AccountBillInfo opbillinfo = new AccountBillInfo();
		ArrayList<AccountBillInfo> opbillInfoList = new ArrayList<AccountBillInfo>();
		opbillInfoList.add(opbillinfo);
		opAccount.setAccBillInfoList(opbillInfoList);
		opAccount.getAccBillInfoList().get(0).setActgFutureDom("04");
		AccountProfile opprofile = new AccountProfile();
		opAccount.setAccountProfile(opprofile);
		opAccount.getAccountProfile().setCoreAccountNumber("CORE-1234");
		
		AttributeValidator.getAttributeValidator().validateAttributes(acctParameters, ipAccount, opAccount);
		AttributeValidator.getAttributeValidator().validateAttributes(acctBillInfoPara, ipAccount.getAccBillInfoList().get(0), opAccount.getAccBillInfoList().get(0));
		AttributeValidator.getAttributeValidator().validateAttributes(acctProfileCoreAcct, ipAccount.getAccountProfile(), opAccount.getAccountProfile());
		
	}
}
