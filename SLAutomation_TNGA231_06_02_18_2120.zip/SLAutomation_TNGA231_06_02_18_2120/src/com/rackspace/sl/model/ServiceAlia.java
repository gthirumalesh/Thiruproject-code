
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class ServiceAlia.
 */
public class ServiceAlia {

    /** The alias id. */
    @SerializedName("aliasId")
    @Expose
    private String aliasId;
    
    /** The alias type. */
    @SerializedName("aliasType")
    @Expose
    private String aliasType;

    /**
     * Gets the alias id.
     *
     * @return the alias id
     */
    public String getAliasId() {
        return aliasId;
    }

    /**
     * Sets the alias id.
     *
     * @param aliasId the new alias id
     */
    public void setAliasId(String aliasId) {
        this.aliasId = aliasId;
    }

    /**
     * Gets the alias type.
     *
     * @return the alias type
     */
    public String getAliasType() {
        return aliasType;
    }

    /**
     * Sets the alias type.
     *
     * @param aliasType the new alias type
     */
    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

}
