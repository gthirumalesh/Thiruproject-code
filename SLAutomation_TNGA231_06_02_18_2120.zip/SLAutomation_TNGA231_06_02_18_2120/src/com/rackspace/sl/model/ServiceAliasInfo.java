
package com.rackspace.sl.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class ServiceAliasInfo.
 */
public class ServiceAliasInfo {

    /** The service alias. */
    @SerializedName("serviceAlias")
    @Expose
    private List<ServiceAlia> serviceAlias = null;

    /**
     * Gets the service alias.
     *
     * @return the service alias
     */
    public List<ServiceAlia> getServiceAlias() {
        return serviceAlias;
    }

    /**
     * Sets the service alias.
     *
     * @param serviceAlias the new service alias
     */
    public void setServiceAlias(List<ServiceAlia> serviceAlias) {
        this.serviceAlias = serviceAlias;
    }

}
