package com.rackspace.sl.payment.action;

import com.rackspace.brm.account.model.Account;
import com.rackspace.sl.payment.dao.PaymentDAO;
import com.rackspace.sl.payment.model.ElectronicCheck;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

public class PaymentAction {

	public ElectronicCheck createACHMethod(ElectronicCheck ipPayment, RBACProfile ipRBACprofile, Account ipAccount)
			throws Exception {

		switch (ipPayment.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPayment = paymentDAO.createACHMethod(ipPayment, ipRBACprofile, ipAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPayment;
	}

	public ElectronicCheck createSupportedMethod(ElectronicCheck ipPayment, RBACProfile ipRBACprofile,
			Account ipAccount) throws Exception {

		switch (ipPayment.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPayment = paymentDAO.getSupportedMethod(ipPayment, ipRBACprofile, ipAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPayment;
	}

	public ElectronicCheck createDefaultMethod(ElectronicCheck ipPayment, RBACProfile ipRBACprofile, Account ipAccount)
			throws Exception {

		switch (ipPayment.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPayment = paymentDAO.doPutDefaultMethod(ipPayment, ipRBACprofile, ipAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPayment;
	}

	public ElectronicCheck createGetDefaultMethod(ElectronicCheck ipPayment, RBACProfile ipRBACprofile,
			Account ipAccount) throws Exception {

		switch (ipPayment.getCardTypes()) {
		case VISA:
			PaymentDAO paymentDAO = new PaymentDAO();
			ipPayment = paymentDAO.setGetDefaultMethod(ipPayment, ipRBACprofile, ipAccount);
			break;
		case MASTERCARD:
			break;
		case DISCOVER:
			break;
		default:
			break;
		}
		return ipPayment;
	}

	public int validatePSLAccount(Account ipAccount, RBACProfile myRBACprofile) throws Exception {

		PaymentDAO paymentdao = new PaymentDAO();

		// paymentdao.getCustomerAccount2(ipAccount, myRBACprofile);

		String acNo = ipAccount.getAccountNumber();
		System.out.println("acNo in AccountAction ===validatePSLAccount=== " + acNo);

		int reponse = paymentdao.getCustomerAccountInPSL(ipAccount, myRBACprofile);

		return reponse;
	}

	/*
	 * validate responsecode in CreateCCMethod
	 */

	public int validateACHMethod(RBACProfile ipRBACProfile, Account opAccount)
			throws Exception {

		PaymentDAO paymentdao = new PaymentDAO();

		//paymentdao.getCustomerAccountCC(ipPayment, ipRBACProfile, opAccount);

		String accountNumber = opAccount.getAccountNumber();
		System.out.println("accountNumber in AccountAction===validateACHMethod=== : " + accountNumber);

		int reponse = paymentdao.validateACHMethod(ipRBACProfile, opAccount);

		return reponse;
	}

	/*
	 * Set Default Method
	 */
	public int validateSetDefaultMethod(ElectronicCheck opPayment,Account opAccount, RBACProfile myRBACprofile) throws Exception {

		PaymentDAO paymentdao = new PaymentDAO();

		// paymentdao.getCustomerAccount1(ipAccount, myRBACprofile);

		String accountNumber = opAccount.getAccountNumber();
		System.out
				.println("accountNumber in AccountAction===validatePSLSetDefaultMethodResponse=== : " + accountNumber);


		return paymentdao.validateSetDefaultMethod(opPayment,opAccount, myRBACprofile);
	}

	/*
	 * validate response code in getSupported method
	 */

	public int validateGetSupportedMethod(Account opAccount, RBACProfile myRBACprofile) throws Exception {

		PaymentDAO paymentdao = new PaymentDAO();

		// paymentdao.getCustomerAccount(opAccount, myRBACprofile);

		String acNo = opAccount.getAccountNumber();
		System.out.println("acNo in AccountAction : " + acNo);

		int reponse = paymentdao.validateGetSupportMethod(opAccount, myRBACprofile);

		return reponse;
	}

}
