package com.rackspace.sl.payment.builder;

import com.rackspace.sl.payment.constants.PaymentConstants.CardTypes;
import com.rackspace.sl.payment.model.ElectronicCheck;

public class PaymentBuilder {
	ElectronicCheck electronicCheck = null;

	public PaymentBuilder(CardTypes cardtypes, String achPaymentType, String accountHolderName, String routingNumber,
			String accountType, String bankAccountNumber) {

		electronicCheck = new ElectronicCheck();
		electronicCheck.setCardTypes(cardtypes);
		electronicCheck.setAchPaymentType(achPaymentType);
		electronicCheck.setAccountHolderName(accountHolderName);
		electronicCheck.setRoutingNumber(routingNumber);
		electronicCheck.setBankAccountNumber(bankAccountNumber);
		electronicCheck.setAccountType(accountType);

	}

	public ElectronicCheck getElectronicCheck() {
		return electronicCheck;
	}

}
