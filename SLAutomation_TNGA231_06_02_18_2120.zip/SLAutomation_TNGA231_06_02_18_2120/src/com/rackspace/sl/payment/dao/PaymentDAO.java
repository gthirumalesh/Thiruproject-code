package com.rackspace.sl.payment.dao;

import java.io.IOException;
import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.portal.pcm.EBufException;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.model.Notification;
import com.rackspace.sl.payment.constants.PaymentConstants;
import com.rackspace.sl.payment.model.ElectronicCheck;
import com.rackspace.sl.payment.model.Payment;
import com.rackspace.sl.payment.model.PaymentResponse;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.RestAssured;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PaymentDAO {

	String inputStringJson = null;

	public ElectronicCheck createACHMethod(ElectronicCheck ipPayment, RBACProfile rbacProfile, Account opAccount)
			throws Exception {
		/*
		 * create ach method
		 */
		String inputStringJSON = prepareAuthXMLfile(ipPayment, rbacProfile, opAccount);

		String uri = PaymentConstants.GET_PSL_ACH_ACCOUNT.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		uri = uri.replace("$accountNumber", opAccount.getAccountNumber());
		System.out.println("PayamentURIPath**createACHMethod**" + uri);
		System.out.println("AccountNumber===createACHMethod===" + opAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionPostWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				inputStringJSON);

		System.out.println("Rest API call end \n");

		System.out.println("RestAPiResponsecode***createACHMethod***" + response.getStatusCode());

		System.out.println("response******createACHMethod******" + response.getStatusCode());
		System.out.println("responseBody****createACHMethod****" + response.getBody());

		// Notification notificationJSONParser = response.as(Notification.class,
		// ObjectMapperType.GSON);

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
		PaymentResponse paymentResponse = response.as(PaymentResponse.class, ObjectMapperType.GSON);

		System.out
				.println("AccountHolderName ======" + payment.getMethod().getElectronicCheck().getAccountHolderName());
		System.out.println("AccountType ======" + payment.getMethod().getElectronicCheck().getAccountType());
		System.out.println("AchPaymentType ======" + payment.getMethod().getElectronicCheck().getAchPaymentType());
		System.out.println("bankAccountNumber ======" + ipPayment.getBankAccountNumber());
		System.out.println("RoutingNumber ======" + payment.getMethod().getElectronicCheck().getRoutingNumber());

		System.out.println("methodID ====== " + paymentResponse.getMethodResponse().getId());

		// ipPayment.setMethodid(paymentResponse.getMethodResponse().getId());
		System.out.println("Ran ====== " + paymentResponse.getMethodResponse().getRan());

		System.out.println("status code for response: " + response.getStatusCode());

		System.out.println("ipPayment**************" + ipPayment);
		ipPayment.setPaymentResponse(paymentResponse);

		return ipPayment;

	}

	/*
	 * finalized method creation prepareXMLfile
	 */

	private String prepareAuthXMLfile(ElectronicCheck ipPayment, RBACProfile rbacProfile, Account opAccount)
			throws Exception {

		String opcTemplate = SLConstants.CREATE_ACH_METHOD_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put("AchPaymentType", ipPayment.getAchPaymentType());
			velocityContext.put("AccountHolderName", ipPayment.getAccountHolderName());
			velocityContext.put("RoutingNumber", ipPayment.getRoutingNumber());
			velocityContext.put("AccountType", ipPayment.getAccountType());
			velocityContext.put("bankAccountNumber", ipPayment.getBankAccountNumber());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("CREATE_ACH_METHOD FILE \n" + writer.toString());
		return writer.toString();

	}

	public ElectronicCheck doPutDefaultMethod(ElectronicCheck ipPayment, RBACProfile myRBACprofile, Account ipAccount)
			throws Exception {

		String inputStringJson = this.preparePutDefaultMethodJsonString(ipAccount, ipPayment, myRBACprofile);

		String uri = PaymentConstants.GET_PSL_SET_DEFAULT_METHOD
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());
		System.out.println("doPutDefaultMethod uri =====" + uri);
		Response response = RestAPIConnection.executePutRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON,
				myRBACprofile.getToken(), inputStringJson);
		System.out.println("response ===" + response);
		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
		// PaymentResponse
		// paymentResponse=response.as(PaymentResponse.class,ObjectMapperType.GSON);

		// System.out.println("ipPayment.getUrnID()=======
		// "+payment.getPaymentResponse().getMethodResponse().getId());
		System.out.println("Token =====    " + myRBACprofile.getToken());
		System.out.println("=====AccountNumber======  " + ipAccount.getAccountNumber());
		System.out.println("Response Code doPutDefaultMethod ==== " + response.getStatusCode());
		return ipPayment;

	}

	/*
	 * setDefault method
	 */

	private String preparePutDefaultMethodJsonString(Account ipAccount, ElectronicCheck ipPayment,
			RBACProfile myRBACprofile) throws Exception {

		String opcTemplate = SLConstants.SET_DEFAULT_ACH_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			// opPayment.getPaymentResponse().getMethodResponse().getId()

			velocityContext.put("URNID", ipPayment.getPaymentResponse().getMethodResponse().getId());
			velocityContext.put("accountNumber", ipAccount.getAccountNumber());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("SetDefaultMethodACH========\n" + writer.toString());
		return writer.toString();
	}

	public ElectronicCheck setGetDefaultMethod(ElectronicCheck ipPayment, RBACProfile rbacProfile, Account ipAccount)
			throws Exception {

		String uri = PaymentConstants.GET_PSL_SET_GET_DEFAULT_METHOD.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		uri = uri.replace("$accountNumber", ipAccount.getAccountNumber()) + SLConstants.SET_GET_DEFAULT_ACH_FILE_PATH;
		System.out.println("setGetDefaultMethod.........." + uri);
		System.out.println("AccountNumber ===============" + ipAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData******" + response.getStatusCode());

		RequestSpecification httpRequest = RestAssured.given().header("X-Auth-Token", rbacProfile.getToken())
				.accept("application/json").contentType("application/json").body("");

		System.out.println("response************" + response.getStatusCode());

		// Notification notificationJSONParser = response.as(Notification.class,
		// ObjectMapperType.GSON);

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);

		// System.out.println("payment.getMethod().getId() =====
		// setGetDefaultMethod ===== " + payment.getMethod().getId());

		// System.out.println(" payment.getMethod().getStatus() " +
		// payment.getMethod().getStatus());

		System.out.println("status code for response: " + response.getStatusCode());

		System.out.println("ipPayment**************" + ipPayment);

		return ipPayment;

	}

	public int getCustomerAccountCC(ElectronicCheck ipPayment, RBACProfile rbacProfile, Account opAccount)
			throws IOException, EBufException, Exception {

		String uri = PaymentConstants.GET_PSL_ACH_ACCOUNT
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", opAccount.getAccountNumber());
		System.out.println("uri==== " + uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		System.out.println("PSL CC Method  Response code" + response.getBody());
		return response.getStatusCode();

	}

	public boolean getCustomerAccount1(Account ipAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = SLConstants.GET_ACCOUNT
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());

		RestAPIConnection.executeGetRestAPIConnectionWithToken(uri, SLConstants.ACCEPT_APPLICATION_JSON,
				SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(), "");

		return true;

	}

	public boolean getCustomerAccount2(Account ipAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = SLConstants.GET_ACCOUNT_PSL
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());

		RestAPIConnection.executeGetRestAPIConnectionWithToken(uri, SLConstants.ACCEPT_APPLICATION_JSON,
				SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(), "");

		return true;

	}
	/*
	 * Validate AccountNumber from PSL
	 */

	public int getCustomerAccountInPSL(Account ipAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = SLConstants.GET_ACCOUNT_PSL
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		System.out.println("response.getStatusCode()===validatePSLAccount===PaymentDAO===" + response.getStatusCode());
		return response.getStatusCode();

	}

	/*
	 * getResponse with create CC Method from PSL
	 */
	public int validateACHMethod(RBACProfile rbacProfile, Account ipAccount)
			throws IOException, EBufException, Exception {
		
		String uri = PaymentConstants.GET_PSL_ACH_ACCOUNT.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT)).replace("$accountNumber", ipAccount.getAccountNumber());
		System.out.println("=========="+uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");

		System.out.println("Responsecode===validateACHMethod===PaymentDAO===" + response.getStatusCode());
		System.out.println("Rest API call end\n");

		return response.getStatusCode();
	}
	
	

	/*
	 * SetDefault Method Response validation
	 */
	public int validateSetDefaultMethod(ElectronicCheck opPayment,Account opAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {
		String inputStringJson = this.preparePutDefaultMethodJsonStringResponse(opPayment,opAccount, rbacProfile);
		String uri = PaymentConstants.GET_PSL_SET_DEFAULT_METHOD
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", opAccount.getAccountNumber());
		System.out.println("getResponseSetDefaultMethod uri === " + uri);
		Response response = RestAPIConnection.executePutRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				inputStringJson);
		
		  PaymentResponse paymentResponse=response.as(PaymentResponse.class, ObjectMapperType.GSON);
		  System.out.println("MethodID ==== "+paymentResponse.getMethodResponse().getId());
		 
		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponse code***getResponseSetDefaultMethod***" + response.getStatusCode());

		return response.getStatusCode();
	}

	private String preparePutDefaultMethodJsonStringResponse(ElectronicCheck opPayment,Account opAccount, RBACProfile rbacProfile) throws Exception {

		String opcTemplate = SLConstants.SET_DEFAULT_ACH_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put("URNID", opPayment.getPaymentResponse().getMethodResponse().getId());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT JSON FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("getResponseSetDefaultMethod ========\n" + writer.toString());
		return writer.toString();
	}
	
	/*
	 * Get supported Method Response from PSL
	 */
	public int validateGetSupportMethod(Account opAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = PaymentConstants.GET_PSL_SUPPORTED_METHODS.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		Response response = RestAPIConnection.executeGetRestAPIConnectionMethodWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				opAccount.getAccountNumber(), "");
		RequestSpecification httpRequest = RestAssured.given().header("X-Auth-Token", rbacProfile.getToken())
				.header("X-Rax-AccountNumber", opAccount.getAccountNumber()).accept("application/json")
				.contentType("application/json").body("");
		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData***getsupportedResponseINPSL***" + response.getStatusCode());
		return response.getStatusCode();
	}

	/*
	 * GetSupported Method for Billing
	 * 
	 */

	public ElectronicCheck getSupportedMethod(ElectronicCheck ipPayment, RBACProfile rbacProfile, Account ipAccount)
			throws Exception {

	
		// String inputStringJSON = prepareAuthXMLString(ipPayment, rbacProfile,
		// opAccount);

		String uri = PaymentConstants.GET_PSL_SUPPORTED_METHODS.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		uri = uri.replace("$accountNumber", ipAccount.getAccountNumber());
		System.out.println("PayamentURIPath****" + uri);
		System.out.println("accountNumber" + ipAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionMethodWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				ipAccount.getAccountNumber(), "");
		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData******" + response.getStatusCode());

		RequestSpecification httpRequest = RestAssured.given().header("X-Auth-Token", rbacProfile.getToken())
				.accept("application/json").contentType("application/json").body("");

		System.out.println("response************" + response.getStatusCode());
		System.out.println("responseBody************" + response.getBody());

		Notification notificationJSONParser = response.as(Notification.class, ObjectMapperType.GSON);

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);

		// Method m1=new Method();

		// System.out.println("payment.getMethod().getId()payment.getMethod().getId()
		// " + payment.getMethod().getId());
		// System.out.println("payment.getMethod().getId()payment.getMethod().getRan()
		// " + payment.getMethod().getRan());
		// System.out.println("payment.getMethod().getId()payment.getMethod().getIsDefault()
		// " + payment.getMethod().getIsDefault());
		// System.out.println("payment.getMethod().getId()payment.getMethod().getStatus()
		// " + payment.getMethod().getStatus());
		System.out.println("notificationJSONParser.getRecipients().get(0).getStatus() "
				+ notificationJSONParser.getRecipients().get(0).getStatus());

		System.out.println("status code for response: " + response.getStatusCode());

		// ipPayment.setCardType(notificationJSONParser.getRecipients().get(0).getStatus());

		// ipPayment.setCardType(payment.getMethod().getId());
		// System.out.println("==========payment.getMethod().getId()=========="
		// + payment.getMethod().getId());

		return ipPayment;

	}

}
