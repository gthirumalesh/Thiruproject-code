
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.rackspace.sl.payment.constants.PaymentConstants.CardTypes;

public class ElectronicCheck {

	@SerializedName("achPaymentType")
	@Expose
	private String achPaymentType;
	@SerializedName("accountHolderName")
	@Expose
	private String accountHolderName;
	@SerializedName("routingNumber")
	@Expose
	private String routingNumber;
	@SerializedName("accountType")
	@Expose
	private String accountType;
	@SerializedName("bankAccountNumber")
	@Expose
	private String bankAccountNumber;
	@SerializedName("paymentResponse")
	@Expose
	private PaymentResponse paymentResponse;

	CardTypes cardTypes = null;

	public String getAchPaymentType() {
		return achPaymentType;
	}

	public void setAchPaymentType(String achPaymentType) {
		this.achPaymentType = achPaymentType;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getRoutingNumber() {
		return routingNumber;
	}

	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public CardTypes getCardTypes() {
		return cardTypes;
	}

	public void setCardTypes(CardTypes cardTypes) {
		this.cardTypes = cardTypes;
	}

	public PaymentResponse getPaymentResponse() {
		return paymentResponse;
	}

	public void setPaymentResponse(PaymentResponse paymentResponse) {
		this.paymentResponse = paymentResponse;
	}

}
