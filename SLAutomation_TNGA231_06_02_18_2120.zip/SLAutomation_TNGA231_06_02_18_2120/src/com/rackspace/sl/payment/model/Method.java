
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Method {

    @SerializedName("disabled")
    @Expose
    private Boolean disabled;
    @SerializedName("electronicCheck")
    @Expose
    private ElectronicCheck electronicCheck;

    public Boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public ElectronicCheck getElectronicCheck() {
        return electronicCheck;
    }

    public void setElectronicCheck(ElectronicCheck electronicCheck) {
        this.electronicCheck = electronicCheck;
    }

}
