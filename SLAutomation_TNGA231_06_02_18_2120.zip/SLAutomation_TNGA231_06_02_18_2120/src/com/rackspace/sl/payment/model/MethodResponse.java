
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MethodResponse {

	@SerializedName("electronicCheck")
	@Expose
	private ElectronicCheckResponse electronicCheckResponse;
	@SerializedName("id")
	@Expose
	private String id;
	@SerializedName("creationDate")
	@Expose
	private String creationDate;
	@SerializedName("isDefault")
	@Expose
	private Boolean isDefault;
	@SerializedName("status")
	@Expose
	private String status;
	@SerializedName("ran")
	@Expose
	private String ran;

	public ElectronicCheckResponse getElectronicCheckResponse() {
		return electronicCheckResponse;
	}

	public void setElectronicCheckResponse(ElectronicCheckResponse electronicCheckResponse) {
		this.electronicCheckResponse = electronicCheckResponse;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRan() {
		return ran;
	}

	public void setRan(String ran) {
		this.ran = ran;
	}

}
