
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaymentResponse {

	@SerializedName("method")
	@Expose
	private MethodResponse methodResponse;

	public MethodResponse getMethodResponse() {
		return methodResponse;
	}

	public void setMethodResponse(MethodResponse methodResponse) {
		this.methodResponse = methodResponse;
	}

}
