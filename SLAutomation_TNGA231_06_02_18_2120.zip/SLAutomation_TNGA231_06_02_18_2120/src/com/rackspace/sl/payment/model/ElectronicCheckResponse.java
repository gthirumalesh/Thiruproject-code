
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ElectronicCheckResponse {

    @SerializedName("accountHolderName")
    @Expose
    private String accountHolderName;
    @SerializedName("routingNumber")
    @Expose
    private String routingNumber;
    @SerializedName("accountNumber")
    @Expose
    private String accountNumber;
    @SerializedName("accountType")
    @Expose
    private String accountType;
    @SerializedName("achPaymentType")
    @Expose
    private String achPaymentType;

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public String getRoutingNumber() {
        return routingNumber;
    }

    public void setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAchPaymentType() {
        return achPaymentType;
    }

    public void setAchPaymentType(String achPaymentType) {
        this.achPaymentType = achPaymentType;
    }

}
