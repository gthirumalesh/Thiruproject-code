package com.rackspace.sl.event.model;

import com.rackspace.sl.event.constants.EventConstants.EventType;

// TODO: Auto-generated Javadoc
/**
 * The Class Template.
 */
public class Event {

	/** The template. */
	String templateID = null;
	
	/** The template ID type. */
	String templateType = null;
	
	/** The get notification status. */
	String notificationStatus = null;
	
	/** The response code. */
	int responseCode;
	
	/** The eventtype. */
	EventType eventtype=null;
	
	/** The notification ID. */
	String notificationID=null;

	/**
	 * Gets the notification ID.
	 *
	 * @return the notification ID
	 */
	public String getNotificationID() {
		return notificationID;
	}

	/**
	 * Sets the notification ID.
	 *
	 * @param notificationID the new notification ID
	 */
	public void setNotificationID(String notificationID) {
		this.notificationID = notificationID;
	}

	/**
	 * Gets the response code.
	 *
	 * @return the response code
	 */
	public int getResponseCode() {
		return responseCode;
	}

	/**
	 * Sets the response code.
	 *
	 * @param responseCode the new response code
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}


	
	/**
	 * Gets the eventtype.
	 *
	 * @return the eventtype
	 */
	public EventType getEventtype() {
		return eventtype;
	}

	/**
	 * Sets the eventtype.
	 *
	 * @param eventtype the new eventtype
	 */
	public void setEventtype(EventType eventtype) {
		this.eventtype = eventtype;
	}
	
	/**
	 * Gets the template ID.
	 *
	 * @return the template ID
	 */
	public String getTemplateID() {
		return templateID;
	}

	/**
	 * Sets the template ID.
	 *
	 * @param templateID the new template ID
	 */
	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}
	
	/**
	 * Gets the template ID type.
	 *
	 * @return the template ID type
	 */
	public String getTemplateType() {
		return templateType;
	}

	/**
	 * Sets the template ID type.
	 *
	 * @param templateIDType the new template ID type
	 */
	public void setTemplateType(String templateIDType) {
		this.templateType = templateIDType;
	}
	

	/**
	 * Gets the notification status.
	 *
	 * @return the notification status
	 */
	public String getNotificationStatus() {
		return notificationStatus;
	}

	/**
	 * Sets the notification status.
	 *
	 * @param notificationStatus the new notification status
	 */
	public void setNotificationStatus(String notificationStatus) {
		this.notificationStatus = notificationStatus;
	}

}
