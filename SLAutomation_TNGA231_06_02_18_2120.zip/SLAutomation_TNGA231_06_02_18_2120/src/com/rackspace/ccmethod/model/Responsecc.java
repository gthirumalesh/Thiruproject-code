
package com.rackspace.ccmethod.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Responsecc {

    @SerializedName("method")
    @Expose
    private Method method;

    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }

}
