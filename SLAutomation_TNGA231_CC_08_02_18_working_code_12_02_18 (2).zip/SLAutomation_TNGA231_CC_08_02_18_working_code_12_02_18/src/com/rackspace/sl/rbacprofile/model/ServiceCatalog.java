
package com.rackspace.sl.rbacprofile.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class ServiceCatalog.
 */
public class ServiceCatalog {

    /** The endpoints. */
    @SerializedName("endpoints")
    @Expose
    private List<Endpoint> endpoints = null;
    
    /** The name. */
    @SerializedName("name")
    @Expose
    private String name;
    
    /** The type. */
    @SerializedName("type")
    @Expose
    private String type;

    /**
     * Gets the endpoints.
     *
     * @return the endpoints
     */
    public List<Endpoint> getEndpoints() {
        return endpoints;
    }

    /**
     * Sets the endpoints.
     *
     * @param endpoints the new endpoints
     */
    public void setEndpoints(List<Endpoint> endpoints) {
        this.endpoints = endpoints;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
        this.type = type;
    }

}
