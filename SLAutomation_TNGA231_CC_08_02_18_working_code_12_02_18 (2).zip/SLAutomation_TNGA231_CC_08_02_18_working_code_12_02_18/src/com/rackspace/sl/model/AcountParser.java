
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.rackspace.brm.account.model.Account;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

/**
 * The Class AcountParser.
 */
public class AcountParser {

    /** The billing account. */
    @SerializedName("billingAccount")
    @Expose
    private BillingAccount billingAccount;

    /**
     * Gets the billing account.
     *
     * @return the billing account
     */
    public BillingAccount getBillingAccount() {
        return billingAccount;
    }

    /**
     * Sets the billing account.
     *
     * @param billingAccount the new billing account
     */
    public void setBillingAccount(BillingAccount billingAccount) {
        this.billingAccount = billingAccount;
    }
    
    /**
     * Parses the create account json.
     *
     * @param response the response
     * @param ipAccount the ip account
     * @return the account
     */
    public static Account parseCreateAccountJson(Response response, Account ipAccount) {
    	Account opAccount = new Account();
    	
    	AcountParser accountParser = response.as(AcountParser.class, ObjectMapperType.GSON);
		String accountNumber = accountParser.getBillingAccount().getAccountNumber();
		String currency = accountParser.getBillingAccount().getCurrency();
		
		System.out.println("Acc number in Account parser from SL ac creation "+ accountNumber);
		System.out.println("Currency in Account parser from SL ac creation "+ currency);
		
		opAccount.setAccountNumber(accountNumber);
		opAccount.setCurrency(currency);
		opAccount.setEndDate(ipAccount.getEndDate());
    	
    	
		return opAccount;
    	
    }

}
