
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Link.
 */
public class Link {

    /** The rel. */
    @SerializedName("rel")
    @Expose
    private String rel;
    
    /** The href. */
    @SerializedName("href")
    @Expose
    private String href;

    /**
     * Gets the rel.
     *
     * @return the rel
     */
    public String getRel() {
        return rel;
    }

    /**
     * Sets the rel.
     *
     * @param rel the new rel
     */
    public void setRel(String rel) {
        this.rel = rel;
    }

    /**
     * Gets the href.
     *
     * @return the href
     */
    public String getHref() {
        return href;
    }

    /**
     * Sets the href.
     *
     * @param href the new href
     */
    public void setHref(String href) {
        this.href = href;
    }

}
