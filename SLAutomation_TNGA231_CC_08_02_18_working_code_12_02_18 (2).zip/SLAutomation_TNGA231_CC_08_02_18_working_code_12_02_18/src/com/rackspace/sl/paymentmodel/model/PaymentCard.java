
package com.rackspace.sl.paymentmodel.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaymentCard {

    @SerializedName("cardHolderName")
    @Expose
    private String cardHolderName;
    @SerializedName("cardNumber")
    @Expose
    private String cardNumber;
    @SerializedName("expirationDate")
    @Expose
    private String expirationDate;
    @SerializedName("cardType")
    @Expose
    private String cardType;
    @SerializedName("level3Eligible")
    @Expose
    private Boolean level3Eligible;

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public Boolean getLevel3Eligible() {
        return level3Eligible;
    }

    public void setLevel3Eligible(Boolean level3Eligible) {
        this.level3Eligible = level3Eligible;
    }

}
