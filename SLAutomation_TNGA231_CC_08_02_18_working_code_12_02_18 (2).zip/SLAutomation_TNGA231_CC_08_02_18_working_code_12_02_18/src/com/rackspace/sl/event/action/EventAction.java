package com.rackspace.sl.event.action;

import com.portal.pcm.FList;
import com.rackspace.brm.account.dao.DedicatedAccountDAO;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.Utils;
import com.rackspace.sl.event.dao.EventDAO;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.globalauth.dao.GlobalAuthDAO;
import com.rackspace.sl.payment.model.PaymentCard;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

/**
 * The Class TemplateAction.
 */
public class EventAction {

	/**
	 * Gets the template by id.
	 *
	 * @param emailTemplateEvent
	 *            the email template event
	 * @param ipRBACprofile
	 *            the op RBA cprofile
	 * @return the template by id
	 * @throws Exception
	 *             the exception
	 */
	public boolean getTemplateById(Event emailTemplateEvent, RBACProfile opRBACprofile) throws Exception {

		EventDAO eventDAO = new EventDAO();
		eventDAO.getTemplateID(emailTemplateEvent, opRBACprofile);

		return true;
	}

	/**
	 * Publish event.
	 *
	 * @param opAccount
	 *            the op account
	 * @param emailTemplateEvent
	 *            the email template event
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 */
	public Account publishEvent(Account opAccount, Event emailTemplateEvent) throws Exception {
		Account account = null;

		EventDAO eventDAO = new EventDAO();
		account = eventDAO.publishEvent(opAccount, emailTemplateEvent);
		return account;

	}

	/**
	 * Gets the notification.
	 *
	 * @param emailNotificationEvent
	 *            the email notification event
	 * @param opRBACprofile
	 *            the op RBA cprofile
	 * @return the notification
	 * @throws Exception
	 *             the exception
	 */
	public Event getNotification(Event emailNotificationEvent, RBACProfile opRBACprofile) throws Exception {
		EventDAO eventDAO;

		switch (emailNotificationEvent.getEventtype()) {
		case GET_NOTIFICATION:
			eventDAO = new EventDAO();
			emailNotificationEvent = eventDAO.getNotificationID(emailNotificationEvent, opRBACprofile);
			System.out.println("emailNotificationEvent.getNotificationStatus() in Action " +emailNotificationEvent.getNotificationStatus());
			
			break;

		default:
			break;

		}

		return emailNotificationEvent;

	}
	
	/**
	 * Gets the notification ID.
	 *
	 * @param accountNumber the account number
	 * @param query the query
	 * @return the notification ID
	 */
	public String getNotificationID(String accountNumber, String query) {
		
		EventDAO eventDAO = new EventDAO();
		String actualNotificationID = eventDAO.getNotificationID(accountNumber, query);
		return actualNotificationID;

	}

}
