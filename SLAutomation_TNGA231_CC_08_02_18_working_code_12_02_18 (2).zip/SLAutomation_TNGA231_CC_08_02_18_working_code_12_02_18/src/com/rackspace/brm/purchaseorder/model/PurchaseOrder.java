package com.rackspace.brm.purchaseorder.model;

import com.rackspace.brm.purchaseorder.constants.PurchaseOrderType;

/**
 * The Class PurchaseOrder.
 */
public abstract class PurchaseOrder {

	/** The purchaseOrderType reference of the PurchaseOrderType */
	PurchaseOrderType purchaseOrderType = null;

	/** The accountNumber represents the account number variable */
	protected String accountNumber = null;

	/** The effectiveDate represents the effective date variable */
	protected String effectiveDate = null;

	/** The tenantID tenant ID represents the tenant ID variable */
	protected String tenantID = null;

	/** The purchaseOrderNumber represents the purchase order number */
	protected String purchaseOrderNumber = null;

	/**
	 * Gets the purchase order number.
	 *
	 * @return the purchase order number
	 */
	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	/**
	 * Sets the purchase order number.
	 *
	 * @param purchaseOrderNumber
	 *            used to store the new purchase order number
	 */
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	/**
	 * Instantiates a new purchase order.
	 *
	 * @param purchaseOrderType
	 *            the purchase order type
	 */
	public PurchaseOrder(PurchaseOrderType purchaseOrderType) {
		this.purchaseOrderType = purchaseOrderType;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber
	 *            the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the effective date.
	 *
	 * @return the effective date
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * Sets the effective date.
	 *
	 * @param effectiveDate
	 *            the new effective date
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * Gets the tenant ID.
	 *
	 * @return the tenant ID
	 */
	public String getTenantID() {
		return tenantID;
	}

	/**
	 * Sets the tenant ID.
	 *
	 * @param tenantID
	 *            the new tenant ID
	 */
	public void setTenantID(String tenantID) {
		this.tenantID = tenantID;
	}

	/**
	 * Gets the purchase order type.
	 *
	 * @return the purchase order type
	 */
	public PurchaseOrderType getPurchaseOrderType() {
		return purchaseOrderType;
	}

	/**
	 * Sets the purchase order type.
	 *
	 * @param purchaseOrderType
	 *            the new purchase order type
	 */
	public void setPurchaseOrderType(PurchaseOrderType purchaseOrderType) {
		this.purchaseOrderType = purchaseOrderType;
	}

}
