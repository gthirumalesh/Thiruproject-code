package com.rackspace.brm.account.model;

/**
 * The Class AccountNameInfo.
 */
public class AccountNameInfo {

	/**
	 * The firstName represents the First Name variable
	 */
	protected String firstName = null;

	/**
	 * The lastName represents the Last Name variable
	 */
	protected String lastName = null;

	/**
	 * The title represents the Title variable
	 */
	protected String title = "Mr.";

	/**
	 * The company name represents the company Name variable
	 */
	protected String companyName = null;

	/**
	 * The city. represents the City variable
	 */
	protected String city = null;

	/**
	 * The state. represents the State variable
	 */
	protected String state = null;

	/**
	 * The country. represents the country variable
	 */
	protected String country = null;

	/**
	 * The canonCountry. represents the cannon country variable
	 */
	protected String canonCountry = null;

	/**
	 * The emailID. represents the email ID variable
	 */
	protected String emailID = null;

	/**
	 * The address. represents the address variable
	 */
	protected String address = null;

	/**
	 * The ZIP. represents the ZIP variable
	 */
	protected String zip = null;

	/**
	 * The phone. represents the phone variable
	 */
	protected String[] phone = null;

	/**
	 * The contactType. represents the contact type variable
	 */
	protected String contactType = null;

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName
	 *            used to set the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            used to set the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the title.
	 *
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the title.
	 *
	 * @param title
	 *            used to set the new title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Gets the company name.
	 *
	 * @return the company name
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * Sets the company name.
	 *
	 * @param companyName
	 *            used to set the new company name
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city
	 *            used to set the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state
	 *            used to set the new state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country
	 *            used to set the new country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the email ID.
	 *
	 * @return the email ID
	 */
	public String getEmailID() {
		return emailID;
	}

	/**
	 * Gets the canon country.
	 *
	 * @return the canon country
	 */
	public String getCanonCountry() {
		return canonCountry;
	}

	/**
	 * Sets the canon country.
	 *
	 * @param canonCountry
	 *            used to set the new canon country
	 */
	public void setCanonCountry(String canonCountry) {
		this.canonCountry = canonCountry;
	}

	/**
	 * Sets the email ID.
	 *
	 * @param emailID
	 *            used to set the new email ID
	 */
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address
	 *            used to set the new address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Gets the zip code.
	 *
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * Sets the zip code.
	 *
	 * @param zip
	 *            used to set the new zip code
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * Gets the contact type.
	 *
	 * @return the contact type
	 */
	public String getContactType() {
		return contactType;
	}

	/**
	 * Sets the contact type.
	 *
	 * @param contactType
	 *            used to set the new contact type
	 */
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public String[] getPhone() {
		return phone;
	}

	/**
	 * Sets the phone.
	 *
	 * @param phone
	 *            used to set the new phone number
	 */
	public void setPhone(String[] phone) {
		this.phone = phone;
	}
}
