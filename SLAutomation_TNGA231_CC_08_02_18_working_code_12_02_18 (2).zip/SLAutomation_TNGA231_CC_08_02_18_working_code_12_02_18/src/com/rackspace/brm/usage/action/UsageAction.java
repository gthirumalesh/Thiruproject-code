package com.rackspace.brm.usage.action;

import java.io.IOException;

import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.model.CommandObject;
import com.rackspace.brm.jobs.BRMJobExecutor;
import com.rackspace.brm.usage.model.DedicatedUsage;
import com.rackspace.brm.usage.model.Usage;

public class UsageAction {

	public UsageAction() {
	}

	public CommandObject createUsage(Usage usage) throws Exception {
		CommandObject commandObject = null;
		//TO BUILD COMMAND OBJECT AS TO EXECUTE THE COMMAND AND RETURN THE RESPONSE : TO DO
		switch(usage.getUsageType()) {
			case DEDICATED:
				DedicatedUsage dedicatedUsage = (DedicatedUsage) (usage);
				String dedicatedUsageFilePath = this.generateDedicatedUsage(dedicatedUsage);
				Utils.APP_LOGS.info("Dedicated Usage File is generated in " + dedicatedUsageFilePath);
				//TO HANDLE THE HARD CODED STRING : TO DO
				BRMJobExecutor.executeDedicatedUsageUEL(dedicatedUsage, dedicatedUsageFilePath);
				break;
			case CLOUD:
				break;
		}
		
		return commandObject;
	}
	
	private String generateDedicatedUsage(DedicatedUsage dedicatedUsage) throws IOException {
		String processedUsageFilePath = null;
		
		try {
			switch(dedicatedUsage.getDedicatedUsageLinesType()) {
			case DAILY:
				Utils.APP_LOGS.info("generating daily dedicated usage file");
				processedUsageFilePath = BRMUtils.buildInputCsvForDailyUsage(dedicatedUsage);
				break;
			case MONTHLY:
				Utils.APP_LOGS.info("generating daily dedicated usage file");
				processedUsageFilePath = BRMUtils.buildInputCsvForMonthlyUsage(dedicatedUsage);
				break;
			}
		} catch(IOException ioEx) {
			throw new IOException("Error occured while generating dedicated usage file : generateDedicatedUsage");
		}
		return processedUsageFilePath;
		
	}
	/*public Usage createDedicatedUsage(String argTenantID, String recordID, String monthYear, double dailyUsageAmount,
			double monthlyUsageAmount, String currency) throws Exception {
		// public Usage postUsage( String argTenantID, String recordID, String
		// monthYear, double dailyUsageAmount, double monthlyUsageAmount, String
		// currency) throws Exception {

		switch (usage.getUsageType()) {

		case DEDICATED:

			DedicatedUsage dedicatedUsage = (DedicatedUsage) (usage);
			dedicatedUsage.setTenantId(argTenantID);
			dedicatedUsage.setRecordId(recordID);
			dedicatedUsage.setMonthYear(monthYear);
			dedicatedUsage.setDailyUsageAmount(dailyUsageAmount);
			dedicatedUsage.setMonthlyUsageAmount(monthlyUsageAmount);
			dedicatedUsage.setCurrency(currency);

			if (dailyUsageAmount > 0) {

				DedicatedUsageDAO dedicatedUsageDAO = new DedicatedUsageDAO();
				String recordAmount = Double.toString(Utils.splitUsageAmountFromTotal(dailyUsageAmount,
						PropertyUtil.getCommonProperties().getProperty("dailyUsageRowsCount")));

				dedicatedUsage.setRecordAmount(recordAmount);
				// String processedUsageFilePath =
				// dedicatedUsageDAO.generateDailyDedicatedUsage(dedicatedUsage);
				String processedUsageFilePath = BRMUtils.buildInputCsvForDailyUsage(dedicatedUsage);

				// BRMJobExecutor.executeDedicatedUsageUEL(dedicatedUsage,processedUsageFilePath);
				BRMJobExecutor.executeDedicatedUsageUEL(dedicatedUsage, processedUsageFilePath, "daily");
			} else if (monthlyUsageAmount > 0) {
				DedicatedUsageDAO dedicatedUsageDAO = new DedicatedUsageDAO();
				String recordAmount = Double.toString(Utils.splitUsageAmountFromTotal(monthlyUsageAmount,
						PropertyUtil.getCommonProperties().getProperty("monthlyUsageRowsCount")));

				dedicatedUsage.setRecordAmount(recordAmount);
				String processedUsageFilePath = BRMUtils.buildInputCsvForMonthlyUsage(dedicatedUsage);

				// BRMJobExecutor.executeDedicatedUsageUEL(dedicatedUsage,processedUsageFilePath);
				BRMJobExecutor.executeDedicatedUsageUEL(dedicatedUsage, processedUsageFilePath, "monthly");

			}

		case CLOUD:
			// account=new CloudAccount();
			break;

		default:
			// logic for expecting if the case is end to switch case

			break;
		}
		return usage;
	}*/

}
