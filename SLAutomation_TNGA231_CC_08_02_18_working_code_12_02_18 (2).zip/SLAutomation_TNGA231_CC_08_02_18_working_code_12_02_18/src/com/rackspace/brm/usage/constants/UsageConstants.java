package com.rackspace.brm.usage.constants;

public final class UsageConstants {

	public static final String DAILY_USAGE_QUERY = "dailyUsageQuery";
	public static final String MONTHLY_USAGE_QUERY = "monthlyUsageQuery";
	
	public enum DedicatedUsageLinesType {DAILY, MONTHLY}
	public enum UsageType {DEDICATED, CLOUD}
	
}
