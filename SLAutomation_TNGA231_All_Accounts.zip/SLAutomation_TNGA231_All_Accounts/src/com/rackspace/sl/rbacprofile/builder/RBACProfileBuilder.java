package com.rackspace.sl.rbacprofile.builder;

import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants.RBACprofileType;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

/**
 * The Class RBACprofileBuilder.
 */
public class RBACProfileBuilder {

	/** The rbac profile. */
	private RBACProfile rbacProfile = null;

	/**
	 * Instantiates a new RBA cprofile builder.
	 *
	 * @param roleType
	 *            the role type
	 */
	public RBACProfileBuilder(RBACprofileType roleType) {
		
		Utils.APP_LOGS.info("Enter: RBACProfileBuilder()");
		
		rbacProfile = new RBACProfile();
		rbacProfile.setRbacProfileType(roleType);
		this.loadCredentials(roleType);
		
		Utils.APP_LOGS.info("Exit: RBACProfileBuilder()");
	}

	/**
	 * Sets the user name.
	 *
	 * @param roleType
	 *            the new user name
	 */
	private void loadCredentials(RBACprofileType roleType) {
		Utils.APP_LOGS.info("Enter: loadCredentials()");
		
		switch (roleType) {
		case BSL_SYSTEM_ROLE:
			rbacProfile.setBslUsername(
					PropertyUtil.getBslProperties().getProperty(RBACProfileConstants.BSL_SYSTEM_ROLE_USERNAME));
			rbacProfile.setBslPassword(
					PropertyUtil.getBslProperties().getProperty(RBACProfileConstants.BSL_SYSTEM_ROLE_PASSWORD));
			break;
		case PROMOTION_AUTH:
			rbacProfile.setBslUsername(
					PropertyUtil.getBslProperties().getProperty(RBACProfileConstants.PROMOTION_AUTH_USERNAME));
			break;
		default:
			break;
		}
		Utils.APP_LOGS.info("Exit: loadCredentials()");
	}

	/**
	 * Gets the RBAc profile.
	 *
	 * @return the RBAc profile
	 */
	public RBACProfile getRBACProfile() {
		return this.rbacProfile;
	}

}
