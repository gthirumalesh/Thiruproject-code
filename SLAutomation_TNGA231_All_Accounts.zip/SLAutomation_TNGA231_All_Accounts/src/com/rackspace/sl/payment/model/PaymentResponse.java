
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentResponse.
 */
public class PaymentResponse {

    /** The method response. */
    @SerializedName("methodResponse")
    @Expose
    private MethodResponse methodResponse;

	/**
	 * Gets the method response.
	 *
	 * @return the method response
	 */
	public MethodResponse getMethodResponse() {
		return methodResponse;
	}

	/**
	 * Sets the method response.
	 *
	 * @param methodResponse the new method response
	 */
	public void setMethodResponse(MethodResponse methodResponse) {
		this.methodResponse = methodResponse;
	}



}
