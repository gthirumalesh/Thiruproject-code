
package com.rackspace.sl.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class ContactInfo.
 */
public class ContactInfo {

    /** The contact. */
    @SerializedName("contact")
    @Expose
    private List<Contact> contact = null;
    
    /** The link. */
    @SerializedName("link")
    @Expose
    private List<Object> link = null;

    /**
     * Gets the contact.
     *
     * @return the contact
     */
    public List<Contact> getContact() {
        return contact;
    }

    /**
     * Sets the contact.
     *
     * @param contact the new contact
     */
    public void setContact(List<Contact> contact) {
        this.contact = contact;
    }

    /**
     * Gets the link.
     *
     * @return the link
     */
    public List<Object> getLink() {
        return link;
    }

    /**
     * Sets the link.
     *
     * @param link the new link
     */
    public void setLink(List<Object> link) {
        this.link = link;
    }

}
