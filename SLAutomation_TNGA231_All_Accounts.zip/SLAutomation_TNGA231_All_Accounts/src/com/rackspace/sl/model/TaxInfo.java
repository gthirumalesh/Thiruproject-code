
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class TaxInfo.
 */
public class TaxInfo {

    /** The business type. */
    @SerializedName("businessType")
    @Expose
    private String businessType;

    /**
     * Gets the business type.
     *
     * @return the business type
     */
    public String getBusinessType() {
        return businessType;
    }

    /**
     * Sets the business type.
     *
     * @param businessType the new business type
     */
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

}
