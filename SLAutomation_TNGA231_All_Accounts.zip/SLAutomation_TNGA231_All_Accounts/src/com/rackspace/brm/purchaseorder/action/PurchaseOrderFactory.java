package com.rackspace.brm.purchaseorder.action;

import com.rackspace.brm.purchaseorder.constants.PurchaseOrderType;
import com.rackspace.brm.purchaseorder.model.CloudPurchaseOrder;
import com.rackspace.brm.purchaseorder.model.DedicatedPurchaseOrder;
import com.rackspace.brm.purchaseorder.model.PurchaseOrder;

/**
 * A factory for creating PurchaseOrder objects.
 */
public class PurchaseOrderFactory {

	/**
	 * Creates a new PurchaseOrder object.
	 *
	 * @param purchaseOrderType
	 *            reference of the PurchaseOrderType class
	 * @return the purchaseOrder object based on the purchaseOrderType like
	 *         DEDICATED or CLOUD
	 */
	public static PurchaseOrder createPurchaseOrder(PurchaseOrderType purchaseOrderType) {
		PurchaseOrder purchaseOrder = null;

		switch (purchaseOrderType) {

		case DEDICATED:

			purchaseOrder = new DedicatedPurchaseOrder();
			break;

		case CLOUD:
			purchaseOrder = new CloudPurchaseOrder();
			break;

		default:

			break;
		}
		return purchaseOrder;
	}
}
