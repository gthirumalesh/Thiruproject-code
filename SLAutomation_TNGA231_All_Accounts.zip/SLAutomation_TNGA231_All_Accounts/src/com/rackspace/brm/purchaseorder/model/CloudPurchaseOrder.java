package com.rackspace.brm.purchaseorder.model;

import com.rackspace.brm.purchaseorder.constants.PurchaseOrderType;

/**
 * The Class CloudPurchaseOrder.
 */
public class CloudPurchaseOrder extends PurchaseOrder {

	/**
	 * Instantiates a new cloud purchase order.
	 */
	public CloudPurchaseOrder() {
		super(PurchaseOrderType.CLOUD);
	}

}
