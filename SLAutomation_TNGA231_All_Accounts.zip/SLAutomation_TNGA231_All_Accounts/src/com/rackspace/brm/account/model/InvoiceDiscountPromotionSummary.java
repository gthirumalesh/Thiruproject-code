package com.rackspace.brm.account.model;

public class InvoiceDiscountPromotionSummary {
	protected String category = null;
	protected String description = null;
	protected double netAmount = 0.0d;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

}
