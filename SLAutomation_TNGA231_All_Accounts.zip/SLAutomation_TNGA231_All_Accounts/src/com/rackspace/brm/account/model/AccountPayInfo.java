package com.rackspace.brm.account.model;

public class AccountPayInfo {

	protected String paymentType = null;
	// Attributes specific to Credit Card
	protected String payType = null;
	protected String paymentOffset = null;
	protected String debitExpiry = null;
	protected String creditCardType = null;

	// Attribute specific to UK DD
	protected String bankCode = null;

	// Attribute specific to NL SEPA
	protected String name = null;
	// Common attributes for payinfo such as CC, ACH DD, UK DD, NL SEPA
	protected String methodId = null;
	protected String debitNum = null;
	protected String bankNo = null;

	public AccountPayInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getPaymentOffset() {
		return paymentOffset;
	}

	public void setPaymentOffset(String paymentOffset) {
		this.paymentOffset = paymentOffset;
	}

	public String getDebitExpiry() {
		return debitExpiry;
	}

	public void setDebitExpiry(String debitExpiry) {
		this.debitExpiry = debitExpiry;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMethodId() {
		return methodId;
	}

	public void setMethodId(String methodId) {
		this.methodId = methodId;
	}

	public String getDebitNum() {
		return debitNum;
	}

	public void setDebitNum(String debitNum) {
		this.debitNum = debitNum;
	}

	public String getBankNo() {
		return bankNo;
	}

	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

}
